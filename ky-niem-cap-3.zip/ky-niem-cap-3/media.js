// ============================================================
// media.js — kho tệp R2 (ảnh gốc, nhạc) + cài đặt tự sinh trong D1
// Gắn R2 trong Cloudflare với TÊN BIẾN: R2. Chưa gắn thì web vẫn chạy như cũ (ảnh nằm trong D1, không có nhạc tải lên).
// ============================================================
const enc = new TextEncoder();
const hex = u8 => Array.from(u8).map(b => (b < 16 ? "0" : "") + b.toString(16)).join("");
export const b64uEnc = u8 => btoa(String.fromCharCode(...new Uint8Array(u8))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
export const b64uDec = s => { s = String(s).replace(/-/g, "+").replace(/_/g, "/"); s += "=".repeat((4 - (s.length % 4)) % 4); return Uint8Array.from(atob(s), c => c.charCodeAt(0)); };

/* ---------- cài đặt dạng khoá-giá trị (tự tạo bảng) ---------- */
let settingsReady = null;
function ensureSettings(env) {
  if (!settingsReady) settingsReady = env.DB.prepare("CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)").run().catch(e => { settingsReady = null; throw e; });
  return settingsReady;
}
export async function getSetting(env, k) {
  await ensureSettings(env);
  const r = await env.DB.prepare("SELECT v FROM settings WHERE k = ?").bind(k).first();
  return r ? r.v : null;
}
/* ghi nếu CHƯA có, rồi đọc lại (an toàn khi hai yêu cầu chạy cùng lúc) */
export async function setSettingOnce(env, k, v) {
  await ensureSettings(env);
  await env.DB.prepare("INSERT OR IGNORE INTO settings (k, v) VALUES (?, ?)").bind(k, v).run();
  return getSetting(env, k);
}

/* ---------- khoá ký đường dẫn ảnh/nhạc (tự sinh, không cần cấu hình) ---------- */
let secretCache = null;
async function getSecret(env) {
  if (env.MEDIA_SECRET) return env.MEDIA_SECRET;
  if (secretCache) return secretCache;
  secretCache = await setSettingOnce(env, "media_secret", hex(crypto.getRandomValues(new Uint8Array(32))));
  return secretCache;
}
async function hmac(secret, msg) {
  const k = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(new Uint8Array(await crypto.subtle.sign("HMAC", k, enc.encode(msg))));
}
function same(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }

/* Đường dẫn có chữ ký, sống 1–2 giờ (cố định trong cùng một giờ để trình duyệt còn nhớ đệm). */
export async function signedUrl(env, key) {
  const exp = (Math.floor(Date.now() / 3600e3) + 2) * 3600;
  return "/media/" + key.split("/").map(encodeURIComponent).join("/") + "?e=" + exp + "&s=" + await hmac(await getSecret(env), key + "." + exp);
}
/* giá trị lưu trong D1: "r2:<khoá>" -> đường dẫn có ký; còn lại (ảnh cũ dạng data:) giữ nguyên */
export async function resolveImg(env, val) {
  if (typeof val === "string" && val.startsWith("r2:")) return signedUrl(env, val.slice(3));
  return val;
}

/* ---------- ghi / xoá ---------- */
export const hasR2 = env => !!(env.R2 && typeof env.R2.put === "function");
export function dataUrlToBytes(d) {
  const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(String(d || ""));
  if (!m) return null;
  const bin = atob(m[2]); const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return { type: m[1], bytes: u, ext: m[1] === "image/jpeg" ? "jpg" : m[1].slice(6) };
}
export async function putImage(env, prefix, dataUrl) {
  const p = dataUrlToBytes(dataUrl); if (!p) return null;
  const key = prefix + "/" + Date.now().toString(36) + hex(crypto.getRandomValues(new Uint8Array(4))) + "." + p.ext;
  await env.R2.put(key, p.bytes, { httpMetadata: { contentType: p.type } });
  return "r2:" + key;
}
export async function delRef(env, val) {
  if (hasR2(env) && typeof val === "string" && val.startsWith("r2:")) { try { await env.R2.delete(val.slice(3)); } catch (e) { /* bỏ qua */ } }
}

/* ---------- phục vụ GET /media/<khoá>?e=&s= (hỗ trợ tua nhạc bằng Range) ---------- */
export async function handleMedia(request, env) {
  const url = new URL(request.url);
  if (!url.pathname.startsWith("/media/")) return null;
  if (request.method !== "GET" && request.method !== "HEAD") return new Response("Method not allowed", { status: 405 });
  if (!hasR2(env)) return new Response("R2 chưa được gắn", { status: 503 });
  let key; try { key = url.pathname.slice(7).split("/").map(decodeURIComponent).join("/"); } catch (e) { return new Response("Bad", { status: 400 }); }
  const exp = parseInt(url.searchParams.get("e") || "0", 10), sig = url.searchParams.get("s") || "";
  if (!key || key.includes("..") || !exp || exp * 1000 < Date.now() || !same(sig, await hmac(await getSecret(env), key + "." + exp))) return new Response("Liên kết đã hết hạn", { status: 403 });
  const ranged = request.headers.has("Range");
  const obj = await env.R2.get(key, ranged ? { range: request.headers } : undefined);
  if (!obj) return new Response("Not found", { status: 404 });
  const h = new Headers(); obj.writeHttpMetadata(h);
  h.set("ETag", obj.httpEtag); h.set("Accept-Ranges", "bytes"); h.set("Cache-Control", "private, max-age=3600");
  let status = 200;
  if (ranged && obj.range) {
    const r = obj.range, off = r.offset !== undefined ? r.offset : obj.size - r.suffix, len = r.length !== undefined ? r.length : obj.size - off;
    h.set("Content-Range", "bytes " + off + "-" + (off + len - 1) + "/" + obj.size); h.set("Content-Length", String(len)); status = 206;
  } else h.set("Content-Length", String(obj.size));
  return new Response(request.method === "HEAD" ? null : obj.body, { status, headers: h });
}

/* ---------- nhạc ---------- */
export const MUSIC_EXT = { mp3: "audio/mpeg", m4a: "audio/mp4", aac: "audio/aac", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/ogg", wav: "audio/wav", webm: "audio/webm" };
export const MUSIC_MAX = 12 * 1024 * 1024;
/* File đặt sẵn trong thư mục web (public/video, public/music, public/img): ref dạng "pub:<thư mục>/<tên file>". Không cần R2. */
const PUB_EXT = { video: "mp4|m4v|webm|mov", music: "mp3|m4a|aac|ogg|oga|opus|wav|webm", img: "jpg|jpeg|png|webp|gif" };
const NAME = "[A-Za-z0-9][A-Za-z0-9._-]{0,80}";
export function pubRef(v, dirs) {           // "pub:video/a.mp4" hoặc chỉ "a.mp4" -> "pub:video/a.mp4" (đoán thư mục theo đuôi file); sai -> null
  v = String(v || "").trim();
  for (const d of dirs) if (new RegExp("^pub:" + d + "\\/" + NAME + "\\.(?:" + PUB_EXT[d] + ")$", "i").test(v) && !v.includes("..")) return v;
  for (const d of dirs) if (new RegExp("^" + NAME + "\\.(?:" + PUB_EXT[d] + ")$", "i").test(v) && !v.includes("..")) return "pub:" + d + "/" + v;
  return null;
}
const pubSrc = ref => "/" + ref.slice(4);

/* nhận link YouTube / mã 11 ký tự -> "yt:<mã>"; "r2:music/..." / file trong public/music giữ nguyên; rỗng -> "" ; sai -> null */
export function parseMusic(v) {
  v = String(v == null ? "" : v).trim(); if (!v) return "";
  const pr = pubRef(v, ["music"]); if (pr) return pr;
  if (/^r2:music\/[A-Za-z0-9._-]{4,80}$/.test(v)) return v;
  if (/^yt:[\w-]{11}$/.test(v)) return v;
  let m = /^[\w-]{11}$/.exec(v); if (m) return "yt:" + v;
  m = /(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/))([\w-]{11})/.exec(v);
  return m ? "yt:" + m[1] : null;
}
/* giá trị lưu -> thứ giao diện dùng để phát */
export async function musicOut(env, ref, title) {
  if (!ref) return null;
  if (ref.startsWith("yt:")) return { kind: "yt", id: ref.slice(3), title: title || "" };
  if (ref.startsWith("pub:")) return { kind: "file", src: pubSrc(ref), title: title || "" };
  if (ref.startsWith("r2:") && hasR2(env)) return { kind: "file", src: await signedUrl(env, ref.slice(3)), title: title || "" };
  return null;
}

/* ---------- video ---------- */
export const VIDEO_EXT = { mp4: "video/mp4", m4v: "video/mp4", webm: "video/webm", mov: "video/quicktime" };
export const VIDEO_MAX = 60 * 1024 * 1024;
export const IMG_EXT = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif" };
export const IMG_MAX = 8 * 1024 * 1024;
/* link YouTube / "yt:<mã>" / "r2:video/..." -> chuẩn hoá; rỗng -> ""; sai -> null */
export function parseVideo(v) {
  v = String(v == null ? "" : v).trim(); if (!v) return "";
  const pr = pubRef(v, ["video", "img"]); if (pr) return pr;
  if (/^r2:(?:video|img)\/[A-Za-z0-9._-]{4,80}$/.test(v)) return v;
  const y = parseMusic(v);
  return y && y.startsWith("yt:") ? y : null;
}
export async function videoOut(env, ref, title) {
  if (!ref) return null;
  if (ref.startsWith("yt:")) return { kind: "yt", id: ref.slice(3), title: title || "" };
  if (ref.startsWith("pub:img/")) return { kind: "img", src: pubSrc(ref), title: title || "" };
  if (ref.startsWith("pub:")) return { kind: "file", src: pubSrc(ref), title: title || "" };
  if (ref.startsWith("r2:img/") && hasR2(env)) return { kind: "img", src: await signedUrl(env, ref.slice(3)), title: title || "" };
  if (ref.startsWith("r2:") && hasR2(env)) return { kind: "file", src: await signedUrl(env, ref.slice(3)), title: title || "" };
  return null;
}
