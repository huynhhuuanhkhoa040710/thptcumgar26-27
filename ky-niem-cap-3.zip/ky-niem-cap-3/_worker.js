/* =====================================================
   _worker.js — "máy chủ" của web, chạy trên Cloudflare + cơ sở dữ liệu D1 (tên gắn: DB) + kho tệp R2 (tên gắn: R2, tuỳ chọn)
   Giữ NGUYÊN tên bảng/cột của bản bạn đã sửa để không mất dữ liệu cũ.
   Web gọi:  POST /api/<tên_lệnh>   |   GET /api/ping
   ===================================================== */
import { handlePush } from './push.js';
import { hasR2, putImage, delRef, resolveImg, handleMedia, parseMusic, musicOut, MUSIC_EXT, MUSIC_MAX, parseVideo, videoOut, VIDEO_EXT, VIDEO_MAX, IMG_EXT, IMG_MAX } from './media.js';

const ITER = 10000;                 // số vòng băm mật khẩu (PBKDF2-SHA256)
const SESSION_MS = 3650 * 864e5;    // đăng nhập một lần, nhớ cho đến khi bấm "Đăng xuất"

/* 2 người điều hành có sẵn. Chỉ lưu MÃ BĂM, không lưu mật khẩu thật. */
const ADMINS = [
  { username: "huynh-huu-anh-khoa", name: "Huỳnh Hữu Anh Khoa", pw: "pbkdf2$10000$35b73710a2afb26c7c875ace7b49fb38$a62322eb1024bb9d8470819a6f70e7495e62f650cbf61fd65be7fc72c7f654e2" },
  { username: "le-duc-anh", name: "Lê Đức Anh", pw: "pbkdf2$10000$e2291899bd06430720a6ca1c23604c8a$9e4925af28e2ccfdc3c6bd1c4088f7a50a1dcf2c84bbc8ba64fb4b89b2fc568b" }
];
/* danh sách lớp để tạo tài khoản lần đầu. Mật khẩu để khoá "!" cho tới khi người điều hành cấp. */
const MEMBERS = [["Nguyễn Thị Bích Liễu","nguyen-thi-bich-lieu"],["Vương Thị Trần An","vuong-thi-tran-an"],["Lê Đức Anh","le-duc-anh"],["Nguyễn Hồ Ngọc Anh","nguyen-ho-ngoc-anh"],["Văn Nguyễn Đức Ân","van-nguyen-duc-an"],["Quách Tấn Dương","quach-tan-duong"],["Lê Huy Bảo","le-huy-bao"],["Ngô Đức Đạo","ngo-duc-dao"],["Nguyễn Minh Đức","nguyen-minh-duc"],["Nguyễn Thị Hồng Hà","nguyen-thi-hong-ha"],["Trịnh Nguyễn Bảo Hiệp","trinh-nguyen-bao-hiep"],["Trần Nguyễn Hoàng","tran-nguyen-hoang"],["Nguyễn Minh Hùng","nguyen-minh-hung"],["Vũ Tuấn Hưng","vu-tuan-hung"],["Nguyễn Quỳnh Hương","nguyen-quynh-huong"],["Phạm Chí Khang","pham-chi-khang"],["Huỳnh Hữu Anh Khoa","huynh-huu-anh-khoa"],["Phan Hoàng Lâm","phan-hoang-lam"],["Đỗ Gia Linh","do-gia-linh"],["Nguyễn Phạm Vy Ly","nguyen-pham-vy-ly"],["Nguyễn Đặng Nhật Minh","nguyen-dang-nhat-minh"],["Huỳnh Hải Nam","huynh-hai-nam"],["Lê Thanh Hưng","le-thanh-hung"],["Ngô Đinh Thảo Nguyên","ngo-dinh-thao-nguyen"],["Phạm Trần Gia Như","pham-tran-gia-nhu"],["Trần Quốc Khánh","tran-quoc-khanh"],["Nguyễn Công Phát","nguyen-cong-phat"],["Lê Hồng Lâm","le-hong-lam"],["Trịnh Thanh Phát","trinh-thanh-phat"],["Trần Ngọc Minh Quang","tran-ngoc-minh-quang"],["Trần Bình Minh","tran-binh-minh"],["Trần Vương Quốc","tran-vuong-quoc"],["Nguyễn Lê Thục Quyên","nguyen-le-thuc-quyen"],["Nguyễn Hữu Trường Sơn","nguyen-huu-truong-son"],["Ngô Việt Tân","ngo-viet-tan"],["Mai Lê Bảo Ngọc","mai-le-bao-ngoc"],["Mai Phương Thảo","mai-phuong-thao"],["Lương Ngọc Tình","luong-ngoc-tinh"],["Phan Nguyễn Huyền Trang","phan-nguyen-huyen-trang"],["Hồ Hà Trâm","ho-ha-tram"],["Ngô Quỳnh Trâm","ngo-quynh-tram"],["Nguyễn Thị Trâm","nguyen-thi-tram"],["Nguyễn Trần Thùy Trâm","nguyen-tran-thuy-tram"],["Tô Trần Bảo Thi","to-tran-bao-thi"],["Phạm Minh Tuấn","pham-minh-tuan"],["Phan Anh Tuấn","phan-anh-tuan"],["Hoàng Duy Hải Vương","hoang-duy-hai-vuong"],["Phạm Nguyễn Triệu Vy","pham-nguyen-trieu-vy"],["Bùi Thị Như Ý","bui-thi-nhu-y"]];

/* ---------- tiện ích ---------- */
const enc = new TextEncoder();
const hex = u8 => Array.from(u8).map(b => (b < 16 ? "0" : "") + b.toString(16)).join("");
const unhex = h => Uint8Array.from(h.match(/../g) || [], x => parseInt(x, 16));
const nowIso = () => new Date().toISOString();
const todayVN = () => new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
const fail = e => ({ ok: false, error: e });
const newToken = () => hex(crypto.getRandomValues(new Uint8Array(24)));
const DATE = /^\d{4}-\d{2}-\d{2}$/, BDAY = /^(\d{4}-)?\d{2}-\d{2}$/;
const isImg = s => typeof s === "string" && s.startsWith("data:image/");
const st = (env, sql, ...b) => env.DB.prepare(sql).bind(...b.map(v => v === undefined ? null : v));
const rows = async (env, sql, ...b) => (await st(env, sql, ...b).all()).results || [];
const row = async (env, sql, ...b) => (await rows(env, sql, ...b))[0] || null;
const exec = (env, sql, ...b) => st(env, sql, ...b).run();

async function pbkdf2(pw, saltHex, iter) {
  const key = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  return hex(new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: unhex(saltHex), iterations: iter }, key, 256)));
}
async function hashPw(pw) { const salt = hex(crypto.getRandomValues(new Uint8Array(16))); return "pbkdf2$" + ITER + "$" + salt + "$" + await pbkdf2(pw, salt, ITER); }
function same(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
async function verifyPw(pw, stored) {            // KHÔNG còn chấp nhận mật khẩu lưu dạng chữ thường
  if (!stored || stored.indexOf("pbkdf2$") !== 0) return false;
  const p = stored.split("$"); if (p.length !== 4) return false;
  return same(await pbkdf2(pw, p[2], parseInt(p[1], 10)), p[3]);
}
const validHash = h => /^pbkdf2\$\d{3,6}\$[0-9a-f]{32}\$[0-9a-f]{64}$/.test(String(h || ""));

/* ---------- khởi tạo + nâng cấp cơ sở dữ liệu (chạy một lần mỗi lần máy chủ khởi động) ---------- */
let dbReady = null;
function initDB(env) {
  if (!dbReady) dbReady = (async () => {
    await env.DB.batch([
      st(env, "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', pw TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 0)"),
      st(env, "CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, uid INTEGER NOT NULL, exp INTEGER NOT NULL)"),
      st(env, "CREATE TABLE IF NOT EXISTS avatars (username TEXT PRIMARY KEY, thumb TEXT, \"full\" TEXT, at TEXT)"),
      st(env, "CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, \"date\" TEXT NOT NULL, emoji TEXT DEFAULT '✨', theme TEXT DEFAULT 'sky', \"desc\" DEFAULT '', body TEXT DEFAULT '', published INTEGER NOT NULL DEFAULT 1, members_only INTEGER NOT NULL DEFAULT 0)"),
      st(env, "CREATE TABLE IF NOT EXISTS photos (id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL, thumb TEXT, \"full\" TEXT, caption TEXT DEFAULT '')"),
      st(env, "CREATE TABLE IF NOT EXISTS letters (id INTEGER PRIMARY KEY AUTOINCREMENT, to_username TEXT NOT NULL, body TEXT NOT NULL, open_on TEXT, author_name TEXT, created TEXT, is_public INTEGER NOT NULL DEFAULT 0)"),
      st(env, "CREATE TABLE IF NOT EXISTS profiles (username TEXT PRIMARY KEY, dob TEXT)"),
      st(env, "CREATE TABLE IF NOT EXISTS attempts (username TEXT NOT NULL, ip TEXT, t INTEGER NOT NULL)"),
      st(env, "CREATE TABLE IF NOT EXISTS avatar_history (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, thumb TEXT, \"full\" TEXT, at TEXT, replaced_at TEXT)"),
      st(env, "CREATE INDEX IF NOT EXISTS ix_avh_user ON avatar_history (username)"),
      st(env, "CREATE TABLE IF NOT EXISTS videos (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, owner INTEGER NOT NULL, ref TEXT NOT NULL, title TEXT, pos INTEGER NOT NULL DEFAULT 0)"),
      st(env, "CREATE INDEX IF NOT EXISTS ix_videos_owner ON videos (kind, owner)"),
    ]);
    /* bảng cũ chưa có cột mới -> thêm vào (đã có rồi thì bỏ qua) */
    for (const sql of ["ALTER TABLE events ADD COLUMN members_only INTEGER NOT NULL DEFAULT 0", "ALTER TABLE letters ADD COLUMN is_public INTEGER NOT NULL DEFAULT 0",
      "ALTER TABLE videos ADD COLUMN k TEXT", "ALTER TABLE users ADD COLUMN avatar_ban_until TEXT", "ALTER TABLE events ADD COLUMN grade INTEGER", "ALTER TABLE events ADD COLUMN music TEXT", "ALTER TABLE events ADD COLUMN music_title TEXT", "ALTER TABLE letters ADD COLUMN music TEXT", "ALTER TABLE letters ADD COLUMN music_title TEXT"]) {
      try { await exec(env, sql); } catch (e) { if (!/duplicate column/i.test(String(e && e.message || e))) throw e; }
    }
    const n = (await row(env, "SELECT COUNT(*) AS c FROM users")).c;
    /* người điều hành tạo TRƯỚC (để vai trò admin không bị ghi đè), rồi mới tới cả lớp */
    await env.DB.batch(ADMINS.map(a => st(env, "INSERT OR IGNORE INTO users (username, name, role, pw, must_change) VALUES (?, ?, 'admin', ?, 0)", a.username, a.name, a.pw)));
    if (n === 0) {
      await env.DB.batch(MEMBERS.map(([name, username]) => st(env, "INSERT OR IGNORE INTO users (username, name, role, pw, must_change) VALUES (?, ?, 'member', '!', 1)", username, name)));
    }
    /* AN TOÀN: mật khẩu mặc định cũ (123456, admin123...) ai cũng biết -> khoá lại. 2 người điều hành quay về mật khẩu riêng đã cấp. */
    for (const a of ADMINS) await exec(env, "UPDATE users SET pw = ? WHERE username = ? AND (pw IS NULL OR pw NOT LIKE 'pbkdf2$%')", a.pw, a.username);
    await exec(env, "UPDATE users SET pw = '!', must_change = 1 WHERE pw IS NULL OR (pw NOT LIKE 'pbkdf2$%' AND pw <> '!')");
  })().catch(e => { dbReady = null; throw e; });
  return dbReady;
}

async function who(env, token) {
  if (!token) return null;
  return await row(env, "SELECT u.id, u.username, u.name, u.role, u.must_change, u.avatar_ban_until FROM users u JOIN sessions s ON s.uid = u.id WHERE s.token = ? AND s.exp > ?", String(token), Date.now());
}
const HIST_MAX = 10;   // mỗi bạn giữ tối đa 10 ảnh đại diện cũ gần nhất
async function archiveAvatar(env, username) {
  const cur = await row(env, "SELECT thumb, \"full\" AS f, at FROM avatars WHERE username = ?", username);
  if (!cur) return;
  await exec(env, "INSERT INTO avatar_history (username, thumb, \"full\", at, replaced_at) VALUES (?, ?, ?, ?, ?)", username, cur.thumb, cur.f, cur.at, nowIso());
  const old = await rows(env, "SELECT id, \"full\" AS f FROM avatar_history WHERE username = ? AND id NOT IN (SELECT id FROM avatar_history WHERE username = ? ORDER BY id DESC LIMIT ?)", username, username, HIST_MAX);
  for (const o of old) await delRef(env, o.f);
  if (old.length) await exec(env, "DELETE FROM avatar_history WHERE username = ? AND id NOT IN (SELECT id FROM avatar_history WHERE username = ? ORDER BY id DESC LIMIT ?)", username, username, HIST_MAX);
}
const banOf = u => (u && u.avatar_ban_until && u.avatar_ban_until > nowIso()) ? u.avatar_ban_until : null;
const pub = u => ({ username: u.username, name: u.name, role: u.role, must_change: !!u.must_change, avatar_ban_until: banOf(u) });
/* bạn đang bị cấm đổi ảnh đại diện (admin đặt theo thời gian): chặn thay / xoá / khôi phục ảnh của chính mình */
const avatarBanned = u => (u && u.role !== "admin") ? banOf(u) : null;
/* ----- video của sự kiện (kind='event') và thư (kind='letter'): nhiều video, mỗi video là file R2 hoặc link YouTube ----- */
/* file đặt sẵn trong public/ (ref "pub:...") phải thật sự có trong thư mục web — kiểm bằng cách hỏi kho file tĩnh */
async function assetMissing(env, refs) {
  if (!env.ASSETS) return false;
  for (const r of refs) {
    if (typeof r !== "string" || !r.startsWith("pub:")) continue;
    try { const res = await env.ASSETS.fetch(new Request("https://assets.invalid/" + r.slice(4), { method: "HEAD" })); if (!res.ok) return true; } catch (e) { return true; }
  }
  return false;
}
const MAX_VIDEOS = 20;   // ảnh + video chèn trong một bài
function cleanVideos(v) {            // undefined/null = giữ nguyên; mảng sai = null
  if (v === undefined || v === null) return undefined;
  if (!Array.isArray(v) || v.length > MAX_VIDEOS) return null;
  const out = [], used = new Set();
  for (const x of v) {
    const ref = parseVideo(x && x.ref); if (!ref) return null; if (out.some(o => o.ref === ref)) continue;
    let k = String((x && x.k) || ""); if (!/^[\w-]{1,12}$/.test(k) || used.has(k)) k = hex(crypto.getRandomValues(new Uint8Array(3)));
    used.add(k); out.push({ ref, k, title: String(x.title || "").trim().slice(0, 80) });
  }
  return out;
}
async function saveVideos(env, kind, owner, list) {
  const old = await rows(env, "SELECT ref FROM videos WHERE kind = ? AND owner = ?", kind, owner);
  await exec(env, "DELETE FROM videos WHERE kind = ? AND owner = ?", kind, owner);
  if (list.length) await env.DB.batch(list.map((x, i) => st(env, "INSERT INTO videos (kind, owner, ref, title, pos, k) VALUES (?, ?, ?, ?, ?, ?)", kind, owner, x.ref, x.title, i, x.k)));
  for (const o of old) if (!list.some(x => x.ref === o.ref)) await delRef(env, o.ref);
}
async function dropVideos(env, kind, owner) { await saveVideos(env, kind, owner, []); }
async function videosOf(env, kind, ids, admin) {      // -> Map(owner -> [video])
  const all = await rows(env, "SELECT id, owner, ref, title, k FROM videos WHERE kind = ? ORDER BY owner, pos, id", kind), m = new Map(), want = new Set(ids);
  for (const r of all) { if (!want.has(r.owner)) continue; const v = await videoOut(env, r.ref, r.title); if (!v) continue; v.k = r.k || ("v" + r.id); if (admin) v.ref = r.ref; (m.get(r.owner) || m.set(r.owner, []).get(r.owner)).push(v); }
  return m;
}
const needAdmin = u => !u ? fail("unauthorized") : (u.role !== "admin" ? fail("forbidden") : null);

/* ---------- các lệnh ---------- */
/* Mật khẩu do lớp cấp (must_change = 1): chỉ NHẮC đổi ở giao diện, không chặn. Các mật khẩu quá dễ đoán bị từ chối khi đổi. */
const COMMON_PW = new Set(["123456", "1234567", "12345678", "123456789", "111111", "000000", "password", "matkhau", "admin123", "qwerty", "abcdef", "lop11a3", "123123"]);
async function handle(cmd, a, env, req) {
  a = a || {};
  switch (cmd) {
    case "app_login": {
      const un = String(a.p_username || "").toLowerCase().slice(0, 80), ip = (req.headers.get("CF-Connecting-IP") || "").slice(0, 60), since = Date.now() - 600000;
      await exec(env, "DELETE FROM attempts WHERE t < ?", Date.now() - 864e5);
      const n1 = (await row(env, "SELECT COUNT(*) AS c FROM attempts WHERE username = ? AND t > ?", un, since)).c;
      const n2 = ip ? (await row(env, "SELECT COUNT(*) AS c FROM attempts WHERE ip = ? AND t > ?", ip, since)).c : 0;
      if (n1 >= 6 || n2 >= 30) return fail("too_many_attempts");
      const u = await row(env, "SELECT * FROM users WHERE username = ?", un);
      if (!u || !(await verifyPw(String(a.p_password || ""), u.pw))) {
        await exec(env, "INSERT INTO attempts (username, ip, t) VALUES (?, ?, ?)", un, ip, Date.now());
        return fail("bad_login");
      }
      const tok = newToken();
      await exec(env, "INSERT INTO sessions (token, uid, exp) VALUES (?, ?, ?)", tok, u.id, Date.now() + SESSION_MS);
      await exec(env, "DELETE FROM sessions WHERE exp < ?", Date.now());
      return { ok: true, token: tok, user: pub(u) };
    }
    case "app_me": { const u = await who(env, a.p_token); return u ? { ok: true, user: pub(u) } : fail("unauthorized"); }
    case "app_logout": { if (a.p_token) await exec(env, "DELETE FROM sessions WHERE token = ?", String(a.p_token)); return { ok: true }; }
    case "app_change_password": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      const full = await row(env, "SELECT pw FROM users WHERE id = ?", u.id);
      if (!(await verifyPw(String(a.p_old || ""), full && full.pw))) return fail("bad_login");
      const np = String(a.p_new || "");
      if (np.length < 6 || np.length > 100 || COMMON_PW.has(np.toLowerCase()) || np.toLowerCase() === u.username) return fail("weak_password");
      if (np === String(a.p_old || "")) return fail("same_password");       // phải khác mật khẩu lớp cấp
      await exec(env, "UPDATE users SET pw = ?, must_change = 0 WHERE id = ?", await hashPw(String(a.p_new)), u.id);
      await exec(env, "DELETE FROM sessions WHERE uid = ? AND token <> ?", u.id, String(a.p_token));
      return { ok: true };
    }

    /* ----- ảnh đại diện ----- */
    case "app_avatars": {
      const since = a.p_since ? new Date(a.p_since).toISOString() : null;
      const list = await rows(env, "SELECT username AS u, at FROM avatars");
      const items = since ? await rows(env, "SELECT username AS u, thumb AS t, at FROM avatars WHERE at > ?", since) : await rows(env, "SELECT username AS u, thumb AS t, at FROM avatars");
      return { ok: true, now: nowIso(), list: list.map(x => ({ u: x.u, at: x.at })), items };
    }
    case "app_avatar_full": { const r = await row(env, "SELECT \"full\" AS f FROM avatars WHERE username = ?", String(a.p_username || "")); return r ? { ok: true, img: await resolveImg(env, r.f) } : fail("not_found"); }
    case "app_set_avatar": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      if (u.role !== "admin" && u.username !== a.p_username) return fail("forbidden");
      { const bn = avatarBanned(u); if (bn) return { ok: false, error: "avatar_banned", until: bn }; }
      if (!(await row(env, "SELECT id FROM users WHERE username = ?", String(a.p_username || "")))) return fail("not_found");
      if (!isImg(a.p_thumb) || !isImg(a.p_full) || a.p_thumb.length > 200000 || a.p_full.length > 1200000) return fail("invalid");
      await archiveAvatar(env, a.p_username);
      let fullVal = a.p_full;
      if (hasR2(env)) fullVal = (await putImage(env, "avatars/" + a.p_username, a.p_full)) || fullVal;   // ảnh gốc vào R2, D1 chỉ giữ ảnh nhỏ
      await exec(env, "INSERT OR REPLACE INTO avatars (username, thumb, \"full\", at) VALUES (?, ?, ?, ?)", a.p_username, a.p_thumb, fullVal, nowIso());
      return { ok: true };
    }
    case "app_del_avatar": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      if (u.role !== "admin" && u.username !== a.p_username) return fail("forbidden");
      { const bn = avatarBanned(u); if (bn) return { ok: false, error: "avatar_banned", until: bn }; }
      await archiveAvatar(env, String(a.p_username || ""));
      await exec(env, "DELETE FROM avatars WHERE username = ?", String(a.p_username || "")); return { ok: true };
    }
    /* ----- lịch sử ảnh đại diện (chính chủ và admin) ----- */
    case "app_avatar_history": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      const target = String(a.p_username || u.username);
      if (u.role !== "admin" && target !== u.username) return fail("forbidden");
      const hs = await rows(env, "SELECT id, thumb, at, replaced_at FROM avatar_history WHERE username = ? ORDER BY id DESC LIMIT ?", target, HIST_MAX);
      return { ok: true, items: hs.map(h => ({ id: h.id, thumb: h.thumb, at: h.at, replaced_at: h.replaced_at })) };
    }
    case "app_avatar_history_full": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      const h = await row(env, "SELECT username, \"full\" AS f FROM avatar_history WHERE id = ?", Number(a.p_id)); if (!h) return fail("not_found");
      if (u.role !== "admin" && h.username !== u.username) return fail("forbidden");
      return { ok: true, img: await resolveImg(env, h.f) };
    }
    case "app_restore_avatar": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      const h = await row(env, "SELECT id, username, thumb, \"full\" AS f FROM avatar_history WHERE id = ?", Number(a.p_id)); if (!h) return fail("not_found");
      if (u.role !== "admin" && h.username !== u.username) return fail("forbidden");
      { const bn = avatarBanned(u); if (bn) return { ok: false, error: "avatar_banned", until: bn }; }
      await exec(env, "DELETE FROM avatar_history WHERE id = ?", h.id);
      await archiveAvatar(env, h.username);
      await exec(env, "INSERT OR REPLACE INTO avatars (username, thumb, \"full\", at) VALUES (?, ?, ?, ?)", h.username, h.thumb, h.f, nowIso());
      return { ok: true };
    }
    case "app_del_avatar_history": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      const h = await row(env, "SELECT username, \"full\" AS f FROM avatar_history WHERE id = ?", Number(a.p_id)); if (!h) return fail("not_found");
      if (u.role !== "admin" && h.username !== u.username) return fail("forbidden");
      { const bn = avatarBanned(u); if (bn) return { ok: false, error: "avatar_banned", until: bn }; }
      await exec(env, "DELETE FROM avatar_history WHERE id = ?", Number(a.p_id)); await delRef(env, h.f); return { ok: true };
    }

    /* ----- ngày sinh ----- */
    case "app_birthdays": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      return { ok: true, items: (await rows(env, "SELECT username AS u, dob FROM profiles WHERE dob IS NOT NULL AND dob <> ''")).map(x => ({ u: x.u, dob: x.dob })) };
    }
    case "app_admin_set_birthdays": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const items = (Array.isArray(a.p_items) ? a.p_items : []).filter(x => x && /^[a-z0-9-]{2,80}$/.test(x.u || "")).slice(0, 300);
      const stm = [];
      items.forEach(x => {
        if (x.d && BDAY.test(x.d)) stm.push(st(env, "INSERT OR REPLACE INTO profiles (username, dob) VALUES (?, ?)", x.u, x.d));
        else if (!x.d) stm.push(st(env, "DELETE FROM profiles WHERE username = ?", x.u));
      });
      if (stm.length) await env.DB.batch(stm);
      return { ok: true, count: stm.length };
    }

    /* ----- sự kiện ----- */
    case "app_events": {
      const u = await who(env, a.p_token), adm = !!(u && u.role === "admin");
      const evs = await rows(env, "SELECT id, title, \"date\" AS d, emoji, theme, \"desc\" AS ds, published, members_only, grade FROM events WHERE published = 1 OR ? = 1 ORDER BY \"date\" DESC, id DESC", adm ? 1 : 0);
      return { ok: true, items: evs.map(e => { const lock = !!e.members_only && !u; return { id: e.id, title: e.title, date: e.d, emoji: e.emoji, theme: e.theme, desc: lock ? "" : (e.ds || ""), published: !!e.published, members_only: !!e.members_only, locked: lock, grade: e.grade || null }; }) };
    }
    case "app_event": {
      const u = await who(env, a.p_token), adm = !!(u && u.role === "admin");
      const e = await row(env, "SELECT id, title, \"date\" AS d, emoji, theme, \"desc\" AS ds, body, published, members_only, music, music_title, grade FROM events WHERE id = ?", Number(a.p_id));
      if (!e || (!e.published && !adm)) return fail("not_found");
      if (e.members_only && !u) return fail("login_required");
      const ph = await rows(env, "SELECT id, thumb, caption FROM photos WHERE event_id = ? ORDER BY id", e.id);
      return { ok: true, event: { id: e.id, title: e.title, date: e.d, emoji: e.emoji, theme: e.theme, desc: e.ds || "", body: e.body || "", published: !!e.published, members_only: !!e.members_only, grade: e.grade || null, music: await musicOut(env, e.music, e.music_title), music_ref: adm ? (e.music || "") : undefined, music_title: adm ? (e.music_title || "") : undefined, videos: (await videosOf(env, "event", [e.id], adm)).get(e.id) || [] }, photos: ph.map(p => ({ id: p.id, thumb: p.thumb, caption: p.caption || "" })) };
    }
    case "app_photo": {
      const u = await who(env, a.p_token);
      const r = await row(env, "SELECT p.\"full\" AS f, e.members_only AS mo FROM photos p JOIN events e ON e.id = p.event_id WHERE p.id = ?", Number(a.p_id));
      if (!r) return fail("not_found"); if (r.mo && !u) return fail("login_required");
      return { ok: true, img: await resolveImg(env, r.f) };
    }
    case "app_save_event": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const title = String(a.p_title || "").trim().slice(0, 120);
      if (!title || !DATE.test(a.p_date || "")) return fail("invalid");
      const v = [title, a.p_date, String(a.p_emoji || "✨").slice(0, 8), String(a.p_theme || "sky").slice(0, 12), String(a.p_desc || "").slice(0, 300), String(a.p_body || "").slice(0, 20000), a.p_published === false ? 0 : 1, a.p_members_only ? 1 : 0];
      const mp = parseMusic(a.p_music === undefined || a.p_music === null ? undefined : a.p_music), keepMusic = a.p_music === undefined || a.p_music === null;
      if (mp === null) return fail("bad_music");
      const vids = cleanVideos(a.p_videos); if (vids === null) return fail("bad_video");
      if (await assetMissing(env, [mp, ...(vids || []).map(v => v.ref)])) return fail("file_missing");
      const gr = [10, 11, 12].includes(Number(a.p_grade)) ? Number(a.p_grade) : null;       // khối lớp của sự kiện (trống = tự suy từ ngày)
      const mt = String(a.p_music_title || "").trim().slice(0, 80);
      if (a.p_id) {
        const ex = await row(env, "SELECT id, music, music_title FROM events WHERE id = ?", Number(a.p_id)); if (!ex) return fail("not_found");
        if (vids) await saveVideos(env, "event", ex.id, vids);
        const nm = keepMusic ? (ex.music || "") : mp, nt = keepMusic ? (ex.music_title || "") : (nm ? mt : "");
        await exec(env, "UPDATE events SET title = ?, \"date\" = ?, emoji = ?, theme = ?, \"desc\" = ?, body = ?, published = ?, members_only = ?, music = ?, music_title = ?, grade = ? WHERE id = ?", ...v, nm || null, nt || null, gr, ex.id);
        if (ex.music && ex.music !== nm) await delRef(env, ex.music);
        return { ok: true, id: ex.id };
      }
      const r = await exec(env, "INSERT INTO events (title, \"date\", emoji, theme, \"desc\", body, published, members_only, music, music_title, grade) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", ...v, mp || null, mp ? mt : null, gr);
      if (vids && vids.length) await saveVideos(env, "event", r.meta.last_row_id, vids);
      return { ok: true, id: r.meta.last_row_id };
    }
    case "app_del_event": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const olds = await rows(env, "SELECT \"full\" AS f FROM photos WHERE event_id = ?", Number(a.p_id)), ev = await row(env, "SELECT music FROM events WHERE id = ?", Number(a.p_id));
      await env.DB.batch([st(env, "DELETE FROM photos WHERE event_id = ?", Number(a.p_id)), st(env, "DELETE FROM events WHERE id = ?", Number(a.p_id))]);
      for (const o of olds) await delRef(env, o.f); if (ev) await delRef(env, ev.music); await dropVideos(env, "event", Number(a.p_id));
      return { ok: true };
    }
    case "app_add_photo": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      if (!isImg(a.p_thumb) || !isImg(a.p_full) || a.p_thumb.length > 200000 || a.p_full.length > 1200000) return fail("invalid");
      const ex = await row(env, "SELECT id FROM events WHERE id = ?", Number(a.p_event)); if (!ex) return fail("not_found");
      let fullVal = a.p_full;
      if (hasR2(env)) fullVal = (await putImage(env, "photos/" + ex.id, a.p_full)) || fullVal;
      const r = await exec(env, "INSERT INTO photos (event_id, thumb, \"full\", caption) VALUES (?, ?, ?, ?)", ex.id, a.p_thumb, fullVal, String(a.p_caption || "").slice(0, 200));
      return { ok: true, id: r.meta.last_row_id };
    }
    case "app_del_photo": { const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e; const ph = await row(env, "SELECT \"full\" AS f FROM photos WHERE id = ?", Number(a.p_id)); await exec(env, "DELETE FROM photos WHERE id = ?", Number(a.p_id)); if (ph) await delRef(env, ph.f); return { ok: true }; }

    /* ----- thư sinh nhật ----- */
    case "app_my_letters": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized"); const td = todayVN();
      const ls = await rows(env, "SELECT id, body, open_on, author_name, created, is_public, music, music_title FROM letters WHERE to_username = ? ORDER BY id DESC", u.username);
      const vm = await videosOf(env, "letter", ls.filter(l => !(l.open_on && l.open_on > td)).map(l => l.id), false);
      return { ok: true, items: await Promise.all(ls.map(async l => { const locked = !!(l.open_on && l.open_on > td); return { id: l.id, from: l.author_name, open_on: l.open_on, locked, body: locked ? null : l.body, created: l.created, is_public: !!l.is_public, music: locked ? null : await musicOut(env, l.music, l.music_title), videos: locked ? [] : (vm.get(l.id) || []) }; })) };
    }
    case "app_public_letters": {
      const td = todayVN();
      const ls = await rows(env, "SELECT l.id, l.body, l.open_on, l.author_name, l.music, l.music_title, t.name AS to_name FROM letters l LEFT JOIN users t ON t.username = l.to_username WHERE l.is_public = 1 AND (l.open_on IS NULL OR l.open_on = '' OR l.open_on <= ?) ORDER BY l.id DESC LIMIT 100", td);
      const vm = await videosOf(env, "letter", ls.map(l => l.id), false);
      return { ok: true, items: await Promise.all(ls.map(async l => ({ id: l.id, to_name: l.to_name || "", from: l.author_name, open_on: l.open_on, body: l.body, music: await musicOut(env, l.music, l.music_title), videos: vm.get(l.id) || [] }))) };
    }
    case "app_set_letter_public": {
      const u = await who(env, a.p_token); if (!u) return fail("unauthorized");
      const l = await row(env, "SELECT id, to_username FROM letters WHERE id = ?", Number(a.p_id)); if (!l) return fail("not_found");
      if (u.role !== "admin" && l.to_username !== u.username) return fail("forbidden");
      await exec(env, "UPDATE letters SET is_public = ? WHERE id = ?", a.p_public ? 1 : 0, l.id); return { ok: true };
    }
    case "app_admin_letters": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const ls = await rows(env, "SELECT l.id, l.to_username, l.body, l.open_on, l.author_name, l.created, l.is_public, l.music, l.music_title, t.name AS to_name FROM letters l LEFT JOIN users t ON t.username = l.to_username ORDER BY l.id DESC");
      const vm = await videosOf(env, "letter", ls.map(l => l.id), true);
      return { ok: true, items: ls.map(l => ({ id: l.id, videos: vm.get(l.id) || [], to: l.to_username, to_name: l.to_name || l.to_username, open_on: l.open_on, body: l.body, author_name: l.author_name, created: l.created, is_public: !!l.is_public, music_ref: l.music || "", music_title: l.music_title || "" })) };
    }
    case "app_save_letter": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const to = await row(env, "SELECT username FROM users WHERE username = ?", String(a.p_to || "")), body = String(a.p_body || "").trim().slice(0, 5000);
      if (!to || !body || (a.p_open_on && !DATE.test(a.p_open_on))) return fail("invalid");
      const pubv = a.p_public ? 1 : 0;
      const keepMusic = a.p_music === undefined || a.p_music === null, mp = keepMusic ? "" : parseMusic(a.p_music);
      if (mp === null) return fail("bad_music");
      const vids = cleanVideos(a.p_videos); if (vids === null) return fail("bad_video");
      if (await assetMissing(env, [mp, ...(vids || []).map(v => v.ref)])) return fail("file_missing");
      const an = String(a.p_author || "").trim().slice(0, 60);           // tên người viết (để trống = giữ nguyên / tên người đang đăng nhập)
      const mt = String(a.p_music_title || "").trim().slice(0, 80);
      if (a.p_id) {
        const ex = await row(env, "SELECT id, music, music_title, author_name FROM letters WHERE id = ?", Number(a.p_id)); if (!ex) return fail("not_found");
        if (vids) await saveVideos(env, "letter", ex.id, vids);
        const nm = keepMusic ? (ex.music || "") : mp, nt = keepMusic ? (ex.music_title || "") : (nm ? mt : "");
        await exec(env, "UPDATE letters SET to_username = ?, body = ?, open_on = ?, is_public = ?, music = ?, music_title = ?, author_name = ? WHERE id = ?", to.username, body, a.p_open_on || null, pubv, nm || null, nt || null, an || ex.author_name || u.name, ex.id);
        if (ex.music && ex.music !== nm) await delRef(env, ex.music);
        return { ok: true, id: ex.id };
      }
      const r = await exec(env, "INSERT INTO letters (to_username, body, open_on, author_name, created, is_public, music, music_title) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", to.username, body, a.p_open_on || null, an || u.name, nowIso(), pubv, mp || null, mp ? mt : null);
      if (vids && vids.length) await saveVideos(env, "letter", r.meta.last_row_id, vids);
      return { ok: true, id: r.meta.last_row_id };
    }
    case "app_del_letter": { const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e; const lt = await row(env, "SELECT music FROM letters WHERE id = ?", Number(a.p_id)); await exec(env, "DELETE FROM letters WHERE id = ?", Number(a.p_id)); if (lt) await delRef(env, lt.music); await dropVideos(env, "letter", Number(a.p_id)); return { ok: true }; }

    /* ----- chuyển ảnh gốc cũ từ D1 sang R2 (admin bấm nhiều lần cho đến khi hết) ----- */
    case "app_admin_migrate_r2": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      if (!hasR2(env)) return fail("no_r2");
      const SRC = [["avatars", "username", "'avatars/' || username"], ["avatar_history", "username", "'avatars/' || username"], ["photos", "event_id", "'photos/' || event_id"]];
      let moved = 0, left = 0;
      for (const [tb, , pref] of SRC) {
        const todo = await rows(env, "SELECT rowid AS rid, \"full\" AS f, " + pref + " AS p FROM " + tb + " WHERE \"full\" LIKE 'data:%' LIMIT ?", Math.max(0, 8 - moved));
        for (const t of todo) { const ref = await putImage(env, t.p, t.f); if (ref) { await exec(env, "UPDATE " + tb + " SET \"full\" = ? WHERE rowid = ?", ref, t.rid); moved++; } }
        left += (await row(env, "SELECT COUNT(*) AS c FROM " + tb + " WHERE \"full\" LIKE 'data:%'")).c;
      }
      return { ok: true, moved, remaining: left };
    }

    /* ----- quản lý tài khoản ----- */
    case "app_admin_users": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      return { ok: true, items: (await rows(env, "SELECT username, name, role, must_change, pw, avatar_ban_until FROM users ORDER BY id")).map(x => ({ username: x.username, name: x.name, role: x.role, must_change: !!x.must_change, locked: x.pw === "!", avatar_ban_until: banOf(x) })) };
    }
    /* cấm / gỡ cấm đổi ảnh đại diện của một bạn (phạt theo thời gian). p_days: 0 = gỡ cấm; tối đa 365 ngày. Có thể dùng p_hours cho thời gian ngắn. */
    case "app_admin_avatar_ban": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const t = await row(env, "SELECT id, role FROM users WHERE username = ?", String(a.p_username || "")); if (!t) return fail("not_found");
      if (t.role === "admin") return fail("forbidden");
      const hrs = Math.max(0, Math.min(365 * 24, Number(a.p_hours) || (Number(a.p_days) || 0) * 24));
      const until = hrs ? new Date(Date.now() + hrs * 3600e3).toISOString() : null;
      await exec(env, "UPDATE users SET avatar_ban_until = ? WHERE id = ?", until, t.id);
      return { ok: true, until };
    }
    case "app_admin_sync_users": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const items = (Array.isArray(a.p_items) ? a.p_items : []).filter(x => x && /^[a-z0-9-]{2,80}$/.test(x.u || "") && String(x.n || "").trim()).slice(0, 300);
      const before = (await row(env, "SELECT COUNT(*) AS c FROM users")).c;
      if (items.length) await env.DB.batch(items.flatMap(x => [
        st(env, "INSERT OR IGNORE INTO users (username, name, role, pw, must_change) VALUES (?, ?, 'member', '!', 1)", x.u, String(x.n).trim().slice(0, 100)),
        st(env, "UPDATE users SET name = ? WHERE username = ?", String(x.n).trim().slice(0, 100), x.u)]));
      return { ok: true, added: (await row(env, "SELECT COUNT(*) AS c FROM users")).c - before };
    }
    case "app_admin_set_passwords": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      const items = (Array.isArray(a.p_items) ? a.p_items : []).filter(x => x && validHash(x.h)).slice(0, 300), mine = String(a.p_token);
      if (items.length) await env.DB.batch(items.flatMap(x => [
        st(env, "UPDATE users SET pw = ?, must_change = 1 WHERE username = ?", x.h, String(x.u)),
        st(env, "DELETE FROM sessions WHERE uid = (SELECT id FROM users WHERE username = ?) AND token <> ?", String(x.u), mine)]));
      return { ok: true, count: items.length };
    }
    case "app_admin_set_role": {
      const u = await who(env, a.p_token), e = needAdmin(u); if (e) return e;
      if (a.p_role !== "admin" && a.p_role !== "member") return fail("invalid");
      const t = await row(env, "SELECT id FROM users WHERE username = ?", String(a.p_username || "")); if (!t) return fail("not_found");
      if (t.id === u.id && a.p_role !== "admin") return fail("forbidden");
      await exec(env, "UPDATE users SET role = ? WHERE id = ?", a.p_role, t.id); return { ok: true };
    }
    default: return fail("unknown_command");
  }
}

/* tải nhạc/video/ảnh lên R2 (chỉ admin): POST /api/music_upload | video_upload | image_upload, thân = tệp, đầu Authorization: Bearer <token>, X-File-Name */
const UPLOADS = { music: [MUSIC_EXT, MUSIC_MAX, "music"], video: [VIDEO_EXT, VIDEO_MAX, "video"], image: [IMG_EXT, IMG_MAX, "img"] };
async function mediaUpload(request, env, kind) {
  const u = await who(env, (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "")), e = needAdmin(u); if (e) return e;
  if (!hasR2(env)) return fail("no_r2");
  const [EXT, MAX, dir] = UPLOADS[kind];
  let name = ""; try { name = decodeURIComponent(request.headers.get("X-File-Name") || ""); } catch (x) { name = ""; }
  const ext = ((/\.([A-Za-z0-9]{2,5})$/.exec(name) || [])[1] || "").toLowerCase();
  if (!EXT[ext]) return fail("bad_type");
  const len = parseInt(request.headers.get("Content-Length") || "0", 10);
  if (len > MAX) return fail("too_big");
  const key = dir + "/" + Date.now().toString(36) + hex(crypto.getRandomValues(new Uint8Array(5))) + "." + ext;
  if (kind === "video") {                      // video lớn: đẩy thẳng (stream) vào R2, không nạp cả file vào bộ nhớ
    if (!len || !request.body) return fail("invalid");
    await env.R2.put(key, request.body, { httpMetadata: { contentType: EXT[ext] } });
  } else {
    const buf = await request.arrayBuffer();
    if (!buf.byteLength) return fail("invalid");
    if (buf.byteLength > MAX) return fail("too_big");
    await env.R2.put(key, buf, { httpMetadata: { contentType: EXT[ext] } });
  }
  return { ok: true, ref: "r2:" + key, title: name.replace(/\.[^.]+$/, "").slice(0, 80) };
}

const HEAD = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };
const reply = (o, status) => new Response(JSON.stringify(o), { status: status || 200, headers: HEAD });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    const media = await handleMedia(request, env);          // ảnh/nhạc có chữ ký trong R2
    if (media) return media;

    // ĐẢM BẢO bảng users/sessions tồn tại cho who() trong push routes
    if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/app_")) {
      await initDB(env);
    }

    // Truyền hàm `who` thật vào handlePush
    const pushResp = await handlePush(request, env, who);
    if (pushResp) return pushResp;

    if (!url.pathname.startsWith("/api/")) return env.ASSETS ? env.ASSETS.fetch(request) : new Response("Not found", { status: 404 });
    if (!env.DB) return reply({ ok: false, error: "no_db" }, 503);
    try {
      // await initDB(env);  ← đã chạy ở trên, có thể xoá dòng này hoặc để lại (cached, không sao)
      const cmd = url.pathname.slice(5);
      if (cmd === "ping") return reply({ ok: true, mode: "cloudflare", r2: hasR2(env) });
      if (request.method !== "POST") return reply({ ok: false, error: "not_found" }, 404);
      if (cmd === "music_upload") return reply(await mediaUpload(request, env, "music"));
      if (cmd === "video_upload") return reply(await mediaUpload(request, env, "video"));
      if (cmd === "image_upload") return reply(await mediaUpload(request, env, "image"));
      let body = {}; try { body = await request.json(); } catch (e) { return reply({ ok: false, error: "invalid" }, 400); }
      return reply(await handle(cmd, body, env, request));
    } catch (e) {
      return reply({ ok: false, error: "server_error", message: String(e && e.message || e) }, 500);
    }
  }
};