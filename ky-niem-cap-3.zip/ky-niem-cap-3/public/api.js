/* =====================================================
   api.js — nói chuyện với "kho dữ liệu" (Supabase) hoặc chế độ thử (lưu trong trình duyệt)
   Mọi hàm đều dùng cùng một bộ lệnh app_*; chế độ thật chạy bằng SQL (supabase/setup.sql),
   chế độ thử chạy bằng JavaScript bên dưới (cùng quy tắc).
   ===================================================== */
(function () {
  "use strict";
  var cfg = (typeof BACKEND !== "undefined" && BACKEND) || {};
  var BASE = cfg.api === undefined ? "/api" : cfg.api;
  var LIVE = false;
  var TK = "lop_token", listeners = {};
  var API = { live: false, modeKnown: false, user: null, demoPass: { member: "123456", admin: "admin123" } };
  /* tự dò: có phần máy chủ (Cloudflare) thì chạy thật, không thì chạy chế độ thử */
  var modeP = (BASE && location.protocol !== "file:" ? new Promise(function (res) {
    var done = false, to = setTimeout(function () { if (!done) { done = true; res(false); } }, 4500);
    fetch(BASE + "/ping", { cache: "no-store" }).then(function (r) { return r.json(); })
      .then(function (j) { if (!done) { done = true; clearTimeout(to); API.r2 = !!(j && j.r2); res(!!(j && j.ok)); } })
      .catch(function () { if (!done) { done = true; clearTimeout(to); res(false); } });
  }) : Promise.resolve(false)).then(function (ok) { LIVE = ok; API.live = ok; API.modeKnown = true; return ok; });
  API.modeReady = modeP;

  function emit(n, d) { (listeners[n] || []).forEach(function (f) { try { f(d); } catch (e) { console.error(e); } }); }
  API.on = function (n, f) { (listeners[n] = listeners[n] || []).push(f); };

  /* ---------- đường truyền thật (Cloudflare Pages: POST /api/<lệnh>) ---------- */
  function liveRpc(name, args) {
    return fetch(BASE + "/" + name, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(args || {}), cache: "no-store" })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (j && j.error === "server_error") throw new Error("Lỗi máy chủ: " + (j.message || ""));
          if (!r.ok && !(j && j.ok === false)) throw new Error("Lỗi mạng " + r.status);
          return j;
        });
      });
  }

  /* ---------- chế độ thử (lưu trong localStorage) ---------- */
  var DKEY = "lop_demo_v1";
  function todayVN() { return new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10); }
  function nowIso() { return new Date().toISOString(); }
  function dseed() {
    var db = { seq: { ev: 0, ph: 0, le: 0 }, users: [], sessions: {}, avatars: {}, events: [], photos: [], letters: [] }, id = 0;
    (typeof MEMBERS !== "undefined" ? MEMBERS : []).forEach(function (m) {
      var u = avatarSlug(m.name), adm = (typeof DEMO_ADMINS !== "undefined" ? DEMO_ADMINS : []).indexOf(u) >= 0;
      db.users.push({ id: ++id, username: u, name: m.name, role: adm ? "admin" : "member", pw: adm ? API.demoPass.admin : API.demoPass.member, must_change: false });
    });
    return db;
  }
  function dload() { try { var s = localStorage.getItem(DKEY); if (s) return JSON.parse(s); } catch (e) {} return dseed(); }
  function dsave(db) { try { localStorage.setItem(DKEY, JSON.stringify(db)); } catch (e) { throw new Error("Bộ nhớ trình duyệt đã đầy (chế độ thử). Hãy dùng ảnh nhỏ hơn."); } }
  function rnd(n) { var s = "", a = "abcdefghijkmnpqrstuvwxyz23456789"; for (var i = 0; i < n; i++) s += a[Math.floor(Math.random() * a.length)]; return s; }
  function demoRpc(name, a) {
    return new Promise(function (res, rej) {
      try { res(demoExec(name, a || {})); } catch (e) { rej(e); }
    });
  }
  function demoExec(name, a) {
    var db = dload(), changed = false, out;
    function uid(tok) { var s = db.sessions[tok]; if (!s || s.exp < Date.now()) return null; for (var i = 0; i < db.users.length; i++) if (db.users[i].id === s.uid) return db.users[i]; return null; }
    function byName(un) { for (var i = 0; i < db.users.length; i++) if (db.users[i].username === un) return db.users[i]; return null; }
    function pub(u) { return { username: u.username, name: u.name, role: u.role, must_change: !!u.must_change }; }
    function need(role) { var u = uid(a.p_token); if (!u) return { err: "unauthorized" }; if (role === "admin" && u.role !== "admin") return { err: "forbidden" }; return { u: u }; }
    function fail(e) { return { ok: false, error: e }; }
    db.avatar_hist = db.avatar_hist || []; db.seq.ah = db.seq.ah || 0;
    function archive(un) {
      var cur = db.avatars[un]; if (!cur) return;
      db.avatar_hist.push({ id: ++db.seq.ah, username: un, thumb: cur.thumb, full: cur.full, at: cur.at, replaced_at: nowIso() });
      var mine = db.avatar_hist.filter(function (h) { return h.username === un; }).sort(function (x, y) { return y.id - x.id; });
      mine.slice(10).forEach(function (h) { db.avatar_hist = db.avatar_hist.filter(function (z) { return z.id !== h.id; }); });
    }
    function histOf(id) { var f = null; db.avatar_hist.forEach(function (h) { if (h.id === id) f = h; }); return f; }
    var g;
    switch (name) {
      case "app_login": {
        var un = String(a.p_username || "").toLowerCase(); db.attempts = (db.attempts || []).filter(function (t) { return Date.now() - t.at < 600000; });
        var n = db.attempts.filter(function (t) { return t.u === un; }).length;
        if (n >= 6) { out = fail("too_many_attempts"); break; }
        var u = byName(un);
        if (!u || u.pw !== String(a.p_password || "")) { db.attempts.push({ u: un, at: Date.now() }); changed = true; out = fail("bad_login"); break; }
        var tok = rnd(32); db.sessions[tok] = { uid: u.id, exp: Date.now() + 3650 * 864e5 }; changed = true;
        out = { ok: true, token: tok, user: pub(u) }; break;
      }
      case "app_me": g = need(); out = g.err ? fail(g.err) : { ok: true, user: pub(g.u) }; break;
      case "app_logout": delete db.sessions[a.p_token]; changed = true; out = { ok: true }; break;
      case "app_change_password": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        if (g.u.pw !== a.p_old) { out = fail("bad_login"); break; }
        if (String(a.p_new || "").length < 6 || ["123456", "111111", "123456789", "password"].indexOf(String(a.p_new)) >= 0) { out = fail("weak_password"); break; }
        if (a.p_new === a.p_old) { out = fail("same_password"); break; }
        g.u.pw = a.p_new; g.u.must_change = false;
        Object.keys(db.sessions).forEach(function (k) { if (db.sessions[k].uid === g.u.id && k !== a.p_token) delete db.sessions[k]; });
        changed = true; out = { ok: true }; break;
      }
      case "app_avatars": {
        var list = [], items = [], since = a.p_since ? new Date(a.p_since).getTime() : null;
        Object.keys(db.avatars).forEach(function (k) { var v = db.avatars[k]; list.push({ u: k, at: v.at }); if (since === null || new Date(v.at).getTime() > since) items.push({ u: k, t: v.thumb, at: v.at }); });
        out = { ok: true, now: nowIso(), list: list, items: items }; break;
      }
      case "app_avatar_full": { var v = db.avatars[a.p_username]; out = v ? { ok: true, img: v.full } : fail("not_found"); break; }
      case "app_set_avatar": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        if (g.u.role !== "admin" && g.u.username !== a.p_username) { out = fail("forbidden"); break; }
        if (!byName(a.p_username)) { out = fail("not_found"); break; }
        if (!a.p_thumb || !a.p_full || a.p_full.length > 900000) { out = fail("invalid"); break; }
        archive(a.p_username); db.avatars[a.p_username] = { thumb: a.p_thumb, full: a.p_full, at: nowIso() }; changed = true; out = { ok: true }; break;
      }
      case "app_del_avatar": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        if (g.u.role !== "admin" && g.u.username !== a.p_username) { out = fail("forbidden"); break; }
        archive(a.p_username); delete db.avatars[a.p_username]; changed = true; out = { ok: true }; break;
      }
      case "app_avatar_history": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        var tg = a.p_username || g.u.username;
        if (g.u.role !== "admin" && tg !== g.u.username) { out = fail("forbidden"); break; }
        out = { ok: true, items: db.avatar_hist.filter(function (h) { return h.username === tg; }).sort(function (x, y) { return y.id - x.id; }).slice(0, 10).map(function (h) { return { id: h.id, thumb: h.thumb, at: h.at, replaced_at: h.replaced_at }; }) }; break;
      }
      case "app_avatar_history_full": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        var hf = histOf(a.p_id); if (!hf) { out = fail("not_found"); break; }
        if (g.u.role !== "admin" && hf.username !== g.u.username) { out = fail("forbidden"); break; }
        out = { ok: true, img: hf.full }; break;
      }
      case "app_restore_avatar": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        var hr = histOf(a.p_id); if (!hr) { out = fail("not_found"); break; }
        if (g.u.role !== "admin" && hr.username !== g.u.username) { out = fail("forbidden"); break; }
        var keep = { thumb: hr.thumb, full: hr.full }; archive(hr.username);
        db.avatars[hr.username] = { thumb: keep.thumb, full: keep.full, at: nowIso() };
        db.avatar_hist = db.avatar_hist.filter(function (h) { return h.id !== a.p_id; }); changed = true; out = { ok: true }; break;
      }
      case "app_del_avatar_history": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        var hd = histOf(a.p_id); if (!hd) { out = fail("not_found"); break; }
        if (g.u.role !== "admin" && hd.username !== g.u.username) { out = fail("forbidden"); break; }
        db.avatar_hist = db.avatar_hist.filter(function (h) { return h.id !== a.p_id; }); changed = true; out = { ok: true }; break;
      }
      case "app_events": {
        g = need(); var adm = !g.err && g.u.role === "admin", logged = !g.err;
        out = { ok: true, items: db.events.filter(function (e) { return e.published || adm; }).sort(function (x, y) { return y.date.localeCompare(x.date) || y.id - x.id; })
          .map(function (e) { var lock = !!e.members_only && !logged; return { id: e.id, title: e.title, date: e.date, emoji: e.emoji, theme: e.theme, desc: lock ? "" : e.desc, published: e.published, members_only: !!e.members_only, locked: lock }; }) };
        break;
      }
      case "app_event": {
        g = need(); var adm2 = !g.err && g.u.role === "admin", ev = null;
        db.events.forEach(function (e) { if (e.id === a.p_id) ev = e; });
        if (!ev || (!ev.published && !adm2)) { out = fail("not_found"); break; }
        if (ev.members_only && g.err) { out = fail("login_required"); break; }
        out = { ok: true, event: ev, photos: db.photos.filter(function (p) { return p.event_id === ev.id; }).sort(function (x, y) { return x.id - y.id; }).map(function (p) { return { id: p.id, thumb: p.thumb, caption: p.caption }; }) }; break;
      }
      case "app_photo": {
        var ph2 = null, pe = null; db.photos.forEach(function (p) { if (p.id === a.p_id) ph2 = p; });
        if (ph2) db.events.forEach(function (e) { if (e.id === ph2.event_id) pe = e; });
        g = need(); if (ph2 && pe && pe.members_only && g.err) { out = fail("login_required"); break; }
        out = ph2 ? { ok: true, img: ph2.full } : fail("not_found"); break;
      }
      case "app_save_event": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        if (!String(a.p_title || "").trim() || !/^\d{4}-\d{2}-\d{2}$/.test(a.p_date || "")) { out = fail("invalid"); break; }
        var rec = { title: String(a.p_title).trim(), date: a.p_date, emoji: a.p_emoji || "✨", theme: a.p_theme || "sky", desc: a.p_desc || "", body: a.p_body || "", published: a.p_published !== false, members_only: !!a.p_members_only };
        if (a.p_id) { var f = null; db.events.forEach(function (e) { if (e.id === a.p_id) f = e; }); if (!f) { out = fail("not_found"); break; } Object.keys(rec).forEach(function (k) { f[k] = rec[k]; }); out = { ok: true, id: f.id }; }
        else { rec.id = ++db.seq.ev; db.events.push(rec); out = { ok: true, id: rec.id }; }
        changed = true; break;
      }
      case "app_del_event": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        db.events = db.events.filter(function (e) { return e.id !== a.p_id; }); db.photos = db.photos.filter(function (p) { return p.event_id !== a.p_id; }); changed = true; out = { ok: true }; break;
      }
      case "app_add_photo": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        if (!a.p_thumb || !a.p_full || a.p_full.length > 900000) { out = fail("invalid"); break; }
        var p = { id: ++db.seq.ph, event_id: a.p_event, thumb: a.p_thumb, full: a.p_full, caption: a.p_caption || "" }; db.photos.push(p); changed = true; out = { ok: true, id: p.id }; break;
      }
      case "app_del_photo": { g = need("admin"); if (g.err) { out = fail(g.err); break; } db.photos = db.photos.filter(function (p) { return p.id !== a.p_id; }); changed = true; out = { ok: true }; break; }
      case "app_my_letters": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        var td = todayVN();
        out = { ok: true, items: db.letters.filter(function (l) { return l.to === g.u.username; }).sort(function (x, y) { return y.id - x.id; }).map(function (l) {
          var locked = !!(l.open_on && l.open_on > td); return { id: l.id, from: l.author_name, open_on: l.open_on, locked: locked, body: locked ? null : l.body, created: l.created, is_public: !!l.is_public }; }) };
        break;
      }
      case "app_public_letters": {
        var td2 = todayVN();
        out = { ok: true, items: db.letters.filter(function (l) { return l.is_public && (!l.open_on || l.open_on <= td2); }).sort(function (x, y) { return y.id - x.id; }).slice(0, 100).map(function (l) { var t = byName(l.to); return { id: l.id, to_name: t ? t.name : "", from: l.author_name, open_on: l.open_on, body: l.body }; }) };
        break;
      }
      case "app_set_letter_public": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        var lp = null; db.letters.forEach(function (l) { if (l.id === a.p_id) lp = l; });
        if (!lp) { out = fail("not_found"); break; }
        if (g.u.role !== "admin" && lp.to !== g.u.username) { out = fail("forbidden"); break; }
        lp.is_public = !!a.p_public; changed = true; out = { ok: true }; break;
      }
      case "app_admin_letters": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        out = { ok: true, items: db.letters.slice().sort(function (x, y) { return y.id - x.id; }).map(function (l) { var t = byName(l.to); return { id: l.id, to: l.to, to_name: t ? t.name : l.to, open_on: l.open_on, body: l.body, author_name: l.author_name, created: l.created, is_public: !!l.is_public }; }) }; break;
      }
      case "app_save_letter": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        if (!byName(a.p_to) || !String(a.p_body || "").trim()) { out = fail("invalid"); break; }
        if (a.p_id) { var l0 = null; db.letters.forEach(function (l) { if (l.id === a.p_id) l0 = l; }); if (!l0) { out = fail("not_found"); break; } l0.to = a.p_to; l0.body = a.p_body; l0.open_on = a.p_open_on || null; l0.is_public = !!a.p_public; out = { ok: true, id: l0.id }; }
        else { var nl = { id: ++db.seq.le, to: a.p_to, body: a.p_body, open_on: a.p_open_on || null, author_name: g.u.name, created: nowIso(), is_public: !!a.p_public }; db.letters.push(nl); out = { ok: true, id: nl.id }; }
        changed = true; break;
      }
      case "app_del_letter": { g = need("admin"); if (g.err) { out = fail(g.err); break; } db.letters = db.letters.filter(function (l) { return l.id !== a.p_id; }); changed = true; out = { ok: true }; break; }
      case "app_admin_users": { g = need("admin"); out = g.err ? fail(g.err) : { ok: true, items: db.users.map(function (u) { var o = pub(u); o.locked = u.pw === "!"; return o; }) }; break; }
      case "app_birthdays": {
        g = need(); if (g.err) { out = fail(g.err); break; }
        db.birthdays = db.birthdays || {};
        out = { ok: true, items: Object.keys(db.birthdays).map(function (k) { return { u: k, dob: db.birthdays[k] }; }) }; break;
      }
      case "app_admin_set_birthdays": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        db.birthdays = db.birthdays || {}; var bc = 0;
        (a.p_items || []).forEach(function (it) {
          if (!it || !/^[a-z0-9-]{2,80}$/.test(it.u || "")) return;
          if (it.d && /^(\d{4}-)?\d{2}-\d{2}$/.test(it.d)) { db.birthdays[it.u] = it.d; bc++; } else if (!it.d) { delete db.birthdays[it.u]; bc++; }
        });
        changed = true; out = { ok: true, count: bc }; break;
      }
      case "app_admin_set_passwords": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        var cnt = 0; (a.p_items || []).forEach(function (it) { var t = byName(it.u); if (t && String(it.p || "").length >= 6) { t.pw = it.p; t.must_change = true; cnt++; Object.keys(db.sessions).forEach(function (k) { if (db.sessions[k].uid === t.id && k !== a.p_token) delete db.sessions[k]; }); } });
        changed = true; out = { ok: true, count: cnt }; break;
      }
      case "app_admin_sync_users": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        var added = 0; (a.p_items || []).forEach(function (it) {
          if (!it || !/^[a-z0-9-]{2,80}$/.test(it.u || "") || !String(it.n || "").trim()) return;
          var ex = byName(it.u); if (ex) { ex.name = String(it.n).trim(); return; }
          db.users.push({ id: db.users.reduce(function (m, x) { return Math.max(m, x.id); }, 0) + 1, username: it.u, name: String(it.n).trim(), role: "member", pw: API.demoPass.member, must_change: false }); added++;
        });
        changed = true; out = { ok: true, added: added }; break;
      }
      case "app_admin_set_role": {
        g = need("admin"); if (g.err) { out = fail(g.err); break; }
        var t2 = byName(a.p_username); if (!t2) { out = fail("not_found"); break; }
        if (a.p_role !== "admin" && a.p_role !== "member") { out = fail("invalid"); break; }
        if (t2.id === g.u.id && a.p_role !== "admin") { out = fail("forbidden"); break; }
        t2.role = a.p_role; changed = true; out = { ok: true }; break;
      }
      default: throw new Error("Lệnh không có: " + name);
    }
    if (changed) dsave(db);
    return out;
  }

  /* ---------- hàm tiện dụng ---------- */
  function rpc(name, args) { return modeP.then(function (live) { return live ? liveRpc(name, args) : demoRpc(name, args); }); }
  API.rpc = rpc;
  API.call = function (name, args) {
    return rpc(name, args).then(function (r) {
      if (r && r.ok === false) {
        var e = new Error(r.error || "error"); e.code = r.error; if (r.until) e.until = r.until;
        throw e;
      }
      return r;
    });
  };
  API.token = function () { try { return localStorage.getItem(TK); } catch (e) { return null; } };
  function setToken(t) { try { if (t) localStorage.setItem(TK, t); else localStorage.removeItem(TK); } catch (e) {} }
  API.isAdmin = function () { return !!(API.user && API.user.role === "admin"); };
  API.init = function () {
    var t = API.token(); if (!t) { emit("auth", null); return Promise.resolve(null); }
    return API.call("app_me", { p_token: t }).then(function (r) { API.user = r.user; emit("auth", API.user); return API.user; })
      .catch(function (e) { if (!e.code || e.code === "unauthorized") setToken(null); API.user = null; emit("auth", null); return null; });
  };
  API.login = function (username, password) {
    return API.call("app_login", { p_username: username, p_password: password }).then(function (r) { setToken(r.token); API.user = r.user; emit("auth", API.user); return r.user; });
  };
  API.logout = function () {
    var t = API.token(); setToken(null); API.user = null; emit("auth", null);
    return t ? rpc("app_logout", { p_token: t }).catch(function () {}) : Promise.resolve();
  };
  API.changePassword = function (o, n) { return API.call("app_change_password", { p_token: API.token(), p_old: o, p_new: n }).then(function () { if (API.user) API.user.must_change = false; emit("auth", API.user); }); };

  /* avatar: bộ nhớ đệm tăng dần */
  function ack() { return "lop_avatars_v2_" + (LIVE ? "cf" : "demo"); }
  function readAv() { try { var c = JSON.parse(localStorage.getItem(ack()) || "{}"); return c || {}; } catch (e) { return {}; } }
  API.avatars = function () {
    var c = readAv(), since = null;
    Object.keys(c).forEach(function (k) { var t = new Date(c[k].at).getTime(); if (c[k].t && (since === null || t > since)) since = t; });
    return API.call("app_avatars", { p_since: since === null ? null : new Date(since).toISOString() }).then(function (r) {
      var map = {};
      r.list.forEach(function (x) { map[x.u] = (c[x.u] && c[x.u].at === x.at && c[x.u].t) ? c[x.u] : { at: x.at }; });
      r.items.forEach(function (x) { map[x.u] = { t: x.t, at: x.at }; });
      Object.keys(map).forEach(function (k) { if (!map[k].t) delete map[k]; });
      try { localStorage.setItem(ack(), JSON.stringify(map)); } catch (e) {}
      return map;
    });
  };
  API.avatarFull = function (u) { return API.call("app_avatar_full", { p_username: u }).then(function (r) { return r.img; }); };
  API.setAvatar = function (u, thumb, full) { return API.call("app_set_avatar", { p_token: API.token(), p_username: u, p_thumb: thumb, p_full: full }); };
  API.delAvatar = function (u) { return API.call("app_del_avatar", { p_token: API.token(), p_username: u }); };
  API.avatarHistory = function (u) { return API.call("app_avatar_history", { p_token: API.token(), p_username: u }).then(function (r) { return r.items; }); };
  API.avatarHistoryFull = function (id) { return API.call("app_avatar_history_full", { p_token: API.token(), p_id: id }).then(function (r) { return r.img; }); };
  API.restoreAvatar = function (id) { return API.call("app_restore_avatar", { p_token: API.token(), p_id: id }); };
  API.delAvatarHistory = function (id) { return API.call("app_del_avatar_history", { p_token: API.token(), p_id: id }); };
  API.events = function () { return API.call("app_events", { p_token: API.token() }).then(function (r) { return r.items; }); };
  API.event = function (id) { return API.call("app_event", { p_token: API.token(), p_id: id }); };
  API.photo = function (id) { return API.call("app_photo", { p_token: API.token(), p_id: id }).then(function (r) { return r.img; }); };
  API.saveEvent = function (e) { return API.call("app_save_event", { p_token: API.token(), p_id: e.id || null, p_title: e.title, p_date: e.date, p_emoji: e.emoji, p_theme: e.theme, p_desc: e.desc, p_body: e.body, p_published: e.published !== false, p_members_only: !!e.members_only, p_grade: e.grade, p_music: e.music, p_music_title: e.music_title, p_videos: e.videos }); };
  API.delEvent = function (id) { return API.call("app_del_event", { p_token: API.token(), p_id: id }); };
  API.addPhoto = function (eid, thumb, full, cap) { return API.call("app_add_photo", { p_token: API.token(), p_event: eid, p_thumb: thumb, p_full: full, p_caption: cap || "" }); };
  /* tải file nhạc lên R2 (chỉ admin, chỉ khi chạy thật) -> { ref, title } */
  function uploadMedia(file, kind, name) {
    return modeP.then(function (live) {
      if (!live) { var e = new Error("Chế độ thử không tải được file. Hãy dán link YouTube."); e.code = "no_r2"; throw e; }
      return fetch(BASE + "/" + kind + "_upload", { method: "POST", headers: { "Authorization": "Bearer " + (API.token() || ""), "X-File-Name": encodeURIComponent(name || file.name || "tep.bin") }, body: file })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (j) { if (!j || j.ok !== true) { var e = new Error((j && (j.message || j.error)) || "error"); e.code = j && j.error; throw e; } return j; });
    });
  };
  API.uploadMusic = function (file) { return uploadMedia(file, "music"); };
  API.uploadVideo = function (file) { return uploadMedia(file, "video"); };
  API.uploadImage = function (blob, name) { return uploadMedia(blob, "image", name || "anh.jpg"); };
  /* admin: cấm đổi ảnh đại diện của một bạn trong `hours` giờ (0 = gỡ cấm) */
  API.adminAvatarBan = function (username, hours) { return API.call("app_admin_avatar_ban", { p_token: API.token(), p_username: username, p_hours: hours }); };
  API.migrateR2 = function () { return API.call("app_admin_migrate_r2", { p_token: API.token() }); };
  API.delPhoto = function (id) { return API.call("app_del_photo", { p_token: API.token(), p_id: id }); };
  API.myLetters = function () { return API.call("app_my_letters", { p_token: API.token() }).then(function (r) { return r.items; }); };
  API.adminLetters = function () { return API.call("app_admin_letters", { p_token: API.token() }).then(function (r) { return r.items; }); };
  API.saveLetter = function (l) { return API.call("app_save_letter", { p_token: API.token(), p_id: l.id || null, p_to: l.to, p_body: l.body, p_open_on: l.open_on || null, p_public: !!l.is_public, p_music: l.music, p_music_title: l.music_title, p_videos: l.videos, p_author: l.author }); };
  API.delLetter = function (id) { return API.call("app_del_letter", { p_token: API.token(), p_id: id }); };
  API.birthdays = function () { return API.call("app_birthdays", { p_token: API.token() }).then(function (r) { return r.items; }); };
  API.adminSetBirthdays = function (items) { return API.call("app_admin_set_birthdays", { p_token: API.token(), p_items: items }); };
  API.publicLetters = function () { return API.call("app_public_letters", {}).then(function (r) { return r.items; }); };
  API.setLetterPublic = function (id, pub) { return API.call("app_set_letter_public", { p_token: API.token(), p_id: id, p_public: !!pub }); };
  API.adminUsers = function () { return API.call("app_admin_users", { p_token: API.token() }).then(function (r) { return r.items; }); };
  function hexOf(u8) { var s = ""; for (var i = 0; i < u8.length; i++) s += (u8[i] < 16 ? "0" : "") + u8[i].toString(16); return s; }
  function hashPw(pw) {
    var salt = new Uint8Array(16); crypto.getRandomValues(salt);
    return crypto.subtle.importKey("raw", new TextEncoder().encode(pw), "PBKDF2", false, ["deriveBits"])
      .then(function (k) { return crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt, iterations: 10000 }, k, 256); })
      .then(function (bits) { return "pbkdf2$10000$" + hexOf(salt) + "$" + hexOf(new Uint8Array(bits)); });
  }
  /* items: [{u:"ten-dang-nhap", p:"mat-khau"}]. Chạy thật: băm ngay trên trình duyệt người điều hành rồi mới gửi (máy chủ chỉ lưu mã băm). */
  API.adminSetPasswords = function (items) {
    return modeP.then(function (live) {
      if (!live) return API.call("app_admin_set_passwords", { p_token: API.token(), p_items: items });
      return Promise.all(items.map(function (it) { return hashPw(it.p).then(function (h) { return { u: it.u, h: h }; }); }))
        .then(function (arr) { return API.call("app_admin_set_passwords", { p_token: API.token(), p_items: arr }); });
    });
  };
  API.adminSyncUsers = function (items) { return API.call("app_admin_sync_users", { p_token: API.token(), p_items: items }); };
  API.adminSetRole = function (u, role) { return API.call("app_admin_set_role", { p_token: API.token(), p_username: u, p_role: role }); };
  API.randomPassword = function (n) { var s = "", a = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789", b = new Uint32Array(n || 8); (window.crypto || window.msCrypto).getRandomValues(b); for (var i = 0; i < b.length; i++) s += a[b[i] % a.length]; return s; };

  /* ---------- xử lý ảnh: thu nhỏ, KHÔNG cắt, không phóng vào mặt ---------- */
  function bitmap(file) {
    if (window.createImageBitmap) return createImageBitmap(file, { imageOrientation: "from-image" }).catch(function () { return viaImg(file); });
    return viaImg(file);
  }
  function viaImg(file) {
    return new Promise(function (res, rej) { var u = URL.createObjectURL(file), im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { rej(new Error("Không đọc được ảnh này.")); }; im.src = u; });
  }
  function shrink(src, w, h, max, q) {
    var s = Math.min(1, max / Math.max(w, h)), cw = Math.max(1, Math.round(w * s)), ch = Math.max(1, Math.round(h * s)), c = document.createElement("canvas");
    c.width = cw; c.height = ch; var x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, cw, ch); x.drawImage(src, 0, 0, cw, ch);
    return c.toDataURL("image/jpeg", q);
  }
  API.img = {
    process: function (file, o) {
      o = o || {};
      return bitmap(file).then(function (b) {
        var w = b.width || b.naturalWidth, h = b.height || b.naturalHeight;
        return { thumb: shrink(b, w, h, o.thumb || 320, .8), full: shrink(b, w, h, o.full || 1000, .82) };
      });
    }
  };
  window.API = API;
})();
