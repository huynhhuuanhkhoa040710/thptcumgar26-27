/* =====================================================
   auth.js — giao diện đăng nhập / tài khoản + bộ công cụ giao diện dùng chung (APP.ui)
   ===================================================== */
(function () {
  "use strict";
  var API = window.API, APP = window.APP;
  if (!API || !APP) return;

  var css = `
  .ap-chip{flex:none;position:relative;width:44px;height:44px;border:1px solid rgba(47,102,201,.25);border-radius:50%;background:#fff;color:#1f3440;font:700 17px "Times New Roman",Georgia,serif;display:grid;place-items:center;cursor:pointer;overflow:hidden;-webkit-tap-highlight-color:transparent;transition:transform .15s,box-shadow .2s}
  .ap-chip:hover{box-shadow:0 6px 16px rgba(47,102,201,.2)}.ap-chip:active{transform:scale(.93)}
  .ap-chip img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 20%}
  .ap-chip.on{background:linear-gradient(135deg,#f08aa6,#e5557c);color:#fff;border-color:transparent}
  .ap-chip.adm{background:linear-gradient(135deg,#f7d36b,#d9992b)}
  .ap-chip .dot{position:absolute;right:3px;bottom:3px;width:11px;height:11px;border-radius:50%;background:#2ecc71;border:2px solid #fff;z-index:2}
  .ap-chip:focus-visible,.ap-btn:focus-visible,.ap-in:focus-visible{outline:3px solid #377f8c;outline-offset:2px}
  .ap-dr{margin:2px 0 12px;display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:20px;background:linear-gradient(135deg,#fff7e0,#ffeef3);border:1px solid rgba(255,255,255,.95);box-shadow:0 4px 14px rgba(36,58,64,.07)}
  .ap-dr .av{flex:none;position:relative;width:46px;height:46px;border-radius:50%;display:grid;place-items:center;overflow:hidden;font:700 19px "Times New Roman",Georgia,serif;color:#fff;background:linear-gradient(135deg,#b7c2c6,#8e9da3)}
  .ap-dr .av img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 20%}
  .ap-dr.on .av{background:linear-gradient(135deg,#f08aa6,#e5557c)}.ap-dr.adm .av{background:linear-gradient(135deg,#f7d36b,#d9992b)}
  .ap-dr .tx{flex:1;min-width:0;line-height:1.3}.ap-dr .tx b{display:block;font-size:15.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ap-dr .tx small{font-size:12.5px;color:#5d7178}
  .ap-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:44px;padding:9px 18px;border:0;border-radius:14px;background:linear-gradient(135deg,#3d78e0,#2f66c9);color:#fff;font:800 15px ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;cursor:pointer;box-shadow:0 8px 18px rgba(47,102,201,.3);text-decoration:none;-webkit-tap-highlight-color:transparent;transition:transform .15s,opacity .2s}
  .ap-btn:active{transform:scale(.96)}.ap-btn:disabled{opacity:.5;cursor:default;box-shadow:none}
  .ap-btn.ghost{background:#fff;color:#2f66c9;box-shadow:inset 0 0 0 1.5px rgba(47,102,201,.35)}
  .ap-btn.danger{background:linear-gradient(135deg,#ef6a5a,#d6453a);box-shadow:0 8px 18px rgba(214,69,58,.3)}
  .ap-btn.sm{min-height:38px;padding:6px 14px;font-size:14px;border-radius:12px}
  .ap-ov{position:fixed;inset:0;z-index:300;display:flex;align-items:flex-end;justify-content:center;background:rgba(14,32,70,.5);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);opacity:0;transition:opacity .25s}
  .ap-ov.on{opacity:1}
  @media(min-width:640px){.ap-ov{align-items:center}}
  .ap-sheet{width:min(100%,460px);max-height:92vh;overflow:auto;padding:20px 18px calc(22px + env(safe-area-inset-bottom));border-radius:28px 28px 0 0;background:linear-gradient(180deg,#fffdf8,#fff);box-shadow:0 -20px 60px rgba(14,32,70,.3);transform:translateY(40px);transition:transform .35s cubic-bezier(.2,.9,.3,1.1);font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#1f3440}
  @media(min-width:640px){.ap-sheet{border-radius:28px}}
  .ap-ov.on .ap-sheet{transform:none}
  .ap-sheet h3{margin:0 0 4px;font-family:"Times New Roman",Georgia,serif;font-size:26px;line-height:1.15}
  .ap-sheet .sub{margin:0 0 14px;color:#5d7178;font-size:14.5px}
  .ap-x{float:right;width:40px;height:40px;margin:-6px -6px 0 8px;border:0;border-radius:50%;background:#f1f4f6;color:#1f3440;font-size:18px;cursor:pointer}
  .ap-lab{display:block;margin:12px 0 6px;font-weight:800;font-size:14px}
  .ap-in{width:100%;min-height:50px;padding:10px 14px;border:1.6px solid #cfdfe2;border-radius:14px;background:#fff;color:#1f3440;font:inherit;font-size:16px}
  .ap-in:focus{outline:none;border-color:#2f66c9;box-shadow:0 0 0 4px rgba(47,102,201,.15)}
  .ap-pw{position:relative}.ap-pw .ap-in{padding-right:52px}
  .ap-eye{position:absolute;right:6px;top:50%;transform:translateY(-50%);width:42px;height:42px;border:0;border-radius:12px;background:transparent;font-size:19px;cursor:pointer}
  .ap-err{min-height:20px;margin:10px 0 0;color:#c0392b;font-weight:700;font-size:14px}
  .ap-note{margin:12px 0 0;padding:10px 12px;border-radius:14px;background:#fff4d6;color:#7a5a12;font-size:13.5px;line-height:1.45}
  .ap-note.ok{background:#e4f6ea;color:#1f6b43}
  .ap-row{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}.ap-row .ap-btn{flex:1 1 140px}
  .ap-me{display:flex;align-items:center;gap:14px;margin:4px 0 6px}
  .ap-me .av{position:relative;flex:none;width:64px;height:64px;border-radius:20px;display:grid;place-items:center;overflow:hidden;color:#fff;font:700 28px "Times New Roman",Georgia,serif;background:linear-gradient(135deg,#f08aa6,#e5557c)}
  .ap-me .av img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 20%}
  .ap-me.adm .av{background:linear-gradient(135deg,#f7d36b,#d9992b)}
  .ap-badge{display:inline-block;margin-top:3px;padding:2px 11px;border-radius:999px;background:#dde8fa;color:#2c58aa;font-size:11.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}
  .ap-badge.adm{background:linear-gradient(135deg,#f7d36b,#d9992b);color:#fff;text-shadow:0 1px 2px rgba(120,80,0,.35)}
  .ap-toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom));z-index:400;width:max-content;max-width:90vw;padding:12px 20px;border-radius:999px;background:rgba(20,42,82,.94);color:#fff;font:650 14.5px ui-sans-serif,system-ui,sans-serif;transform:translate(-50%,30px);opacity:0;pointer-events:none;transition:opacity .3s,transform .3s;text-align:center}
  .ap-toast.on{opacity:1;transform:translate(-50%,0)}
  .ap-vw{position:fixed;inset:0;z-index:320;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:calc(env(safe-area-inset-top) + 14px) 12px calc(env(safe-area-inset-bottom) + 14px);background:rgba(10,14,30,.94);opacity:0;visibility:hidden;transition:opacity .3s,visibility 0s .3s}
  .ap-vw.on{opacity:1;visibility:visible;transition:opacity .3s}
  .ap-vw img{max-width:100%;max-height:74vh;border-radius:14px;box-shadow:0 30px 80px rgba(0,0,0,.6);background:#222;min-width:120px;min-height:120px;object-fit:contain}
  .ap-vw p{margin:0;color:rgba(255,255,255,.92);font:italic 18px "Times New Roman",Georgia,serif;text-align:center}
  .ap-vw .acts{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}
  .ap-vw .cl{position:absolute;top:calc(env(safe-area-inset-top) + 12px);right:12px;width:46px;height:46px;border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;font-size:22px;cursor:pointer}
  .ap-hint{margin:12px 0 0;padding:10px 12px;border-radius:14px;background:#eaf2fd;color:#24508f;font-size:13.5px;line-height:1.45;text-align:center}
  .ap-gate{position:fixed;inset:0;z-index:450;display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:calc(env(safe-area-inset-top) + 24px) 16px calc(env(safe-area-inset-bottom) + 24px);
    background:radial-gradient(ellipse at 15% 8%,#f9d3df 0%,transparent 40%),radial-gradient(ellipse at 90% 30%,#d3e6f6 0%,transparent 40%),radial-gradient(ellipse at 20% 95%,#fbe7bd 0%,transparent 38%),linear-gradient(180deg,#fff1f4,#fffaf3 60%,#eaf3f8);opacity:0;transition:opacity .4s}
  .ap-gate.on{opacity:1}
  .ap-gate-card{width:min(100%,440px);margin:auto;padding:26px 22px 22px;border-radius:30px;background:rgba(255,255,255,.92);border:1px solid rgba(255,255,255,.95);box-shadow:0 24px 60px rgba(229,85,124,.2);font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#1f3440;transform:translateY(24px);transition:transform .5s cubic-bezier(.2,.9,.3,1.1)}
  .ap-gate.on .ap-gate-card{transform:none}
  .ap-gate-e{font-size:50px;text-align:center;line-height:1;animation:apbob 3.2s ease-in-out infinite}
  @keyframes apbob{50%{transform:translateY(-6px) rotate(6deg)}}
  .ap-gate-card h2{margin:8px 0 2px;text-align:center;font:700 clamp(26px,7vw,32px)/1.15 "Times New Roman",Georgia,serif}
  .ap-gate-s{margin:0 0 6px;text-align:center;color:#5d7178;font-size:14px}
  .ap-or{display:flex;align-items:center;gap:10px;margin:18px 0 12px;color:#8a9aa0;font-size:13px;text-transform:uppercase;letter-spacing:.1em}
  .ap-or:before,.ap-or:after{content:"";flex:1;height:1px;background:rgba(61,100,115,.18)}
  .ap-hist{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px;margin-top:6px}
  .ap-h{display:flex;flex-direction:column;gap:6px;padding:8px;border-radius:18px;background:#faf6ee;border:1px solid #efe5d3}
  .ap-h img{width:100%;aspect-ratio:4/5;object-fit:cover;object-position:50% 20%;border-radius:12px;cursor:zoom-in;background:#e6edf2}
  .ap-h small{color:#5d7178;font-size:12px;text-align:center}
  .ap-hb{display:flex;gap:6px}.ap-hb .ap-btn{flex:1;min-height:36px;padding:6px 6px;font-size:13px}
  .ap-lock{margin:14px 0;padding:22px 18px;border-radius:24px;border:1.5px dashed rgba(47,102,201,.35);background:rgba(255,255,255,.7);text-align:center;color:#42585f}
  .ap-lock b{display:block;margin-bottom:4px;font:700 20px "Times New Roman",Georgia,serif;color:#1f3440}
  .ap-lock .ap-btn{margin-top:12px}
  html[data-fx="off"] .ap-gate,html[data-fx="off"] .ap-gate-card,html[data-fx="off"] .ap-gate-e{transition:none!important;animation:none!important}
  html[data-fx="off"] .ap-ov,html[data-fx="off"] .ap-sheet,html[data-fx="off"] .ap-vw,html[data-fx="off"] .ap-toast{transition:none!important}`;
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  var norm = function (s) { return String(s).replace(/đ/g, "d").replace(/Đ/g, "D").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim(); };
  var given = function (n) { var p = String(n).trim().split(/\s+/); return p[p.length - 1]; };
  var initial = function (n) { return Array.from(given(n))[0].toUpperCase(); };

  /* ---------- bộ công cụ giao diện ---------- */
  var ui = {}, lockN = 0;
  function lock(on) { lockN += on ? 1 : -1; if (lockN < 0) lockN = 0; document.documentElement.style.overflow = lockN ? "hidden" : ""; }
  var toastEl = null, toastT;
  ui.toast = function (msg) {
    if (!toastEl) { toastEl = el("div", "ap-toast"); toastEl.setAttribute("role", "status"); toastEl.setAttribute("aria-live", "polite"); document.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(function () { toastEl.classList.remove("on"); }, 2600);
  };
  ui.sheet = function (title, sub) {
    var ov = el("div", "ap-ov"), sh = el("div", "ap-sheet"), x = el("button", "ap-x", "✕");
    x.type = "button"; x.setAttribute("aria-label", "Đóng");
    var h = el("h3"); h.textContent = title; sh.appendChild(x); sh.appendChild(h);
    if (sub) { var p = el("p", "sub"); p.textContent = sub; sh.appendChild(p); }
    var body = el("div"); sh.appendChild(body); ov.appendChild(sh); document.body.appendChild(ov); lock(true);
    var closed = false, prevFocus = document.activeElement;
    function close() { if (closed) return; closed = true; ov.classList.remove("on"); lock(false); document.removeEventListener("keydown", key); setTimeout(function () { ov.remove(); }, 260); try { prevFocus && prevFocus.focus(); } catch (e) {} }
    function key(e) { if (e.key === "Escape") close(); }
    x.addEventListener("click", close); ov.addEventListener("click", function (e) { if (e.target === ov) close(); }); document.addEventListener("keydown", key);
    requestAnimationFrame(function () { ov.classList.add("on"); });
    return { el: ov, sheet: sh, body: body, close: close };
  };
  ui.pick = function (accept, multi) {
    return new Promise(function (res) {
      var i = document.createElement("input"); i.type = "file"; i.accept = accept || "image/*"; if (multi) i.multiple = true; i.style.display = "none";
      i.addEventListener("change", function () { res(Array.prototype.slice.call(i.files || [])); i.remove(); }); document.body.appendChild(i); i.click();
    });
  };
  /* xem ảnh đầy đủ (không cắt, không phóng vào mặt) */
  ui.viewer = function (o) {
    var ov = el("div", "ap-vw"), cl = el("button", "cl", "✕"), im = el("img"), cap = el("p"), acts = el("div", "acts");
    cl.type = "button"; cl.setAttribute("aria-label", "Đóng ảnh"); im.alt = o.alt || ""; cap.textContent = o.caption || "";
    if (o.thumb) im.src = o.thumb;
    ov.appendChild(cl); ov.appendChild(im); if (o.caption) ov.appendChild(cap);
    (o.actions || []).forEach(function (a) { var b = el("button", "ap-btn sm" + (a.cls ? " " + a.cls : "")); b.type = "button"; b.textContent = a.label; b.addEventListener("click", function (e) { e.stopPropagation(); a.run(close); }); acts.appendChild(b); });
    if ((o.actions || []).length) ov.appendChild(acts);
    document.body.appendChild(ov); lock(true); requestAnimationFrame(function () { ov.classList.add("on"); });
    var closed = false;
    function close() { if (closed) return; closed = true; ov.classList.remove("on"); lock(false); document.removeEventListener("keydown", key); setTimeout(function () { ov.remove(); }, 320); }
    function key(e) { if (e.key === "Escape") close(); }
    ov.addEventListener("click", function (e) { if (e.target === ov || e.target === im) close(); }); cl.addEventListener("click", close); document.addEventListener("keydown", key);
    if (o.full) Promise.resolve(typeof o.full === "function" ? o.full() : o.full).then(function (src) { if (src) im.src = src; }).catch(function () {});
    return { close: close };
  };
  ui.errText = function (e) {
    if (e && e.code === "avatar_banned") return "Bạn đang bị tạm cấm đổi ảnh đại diện" + (e.until ? " đến " + new Date(e.until).toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit", year: "numeric" }) : "") + ".";
    var m = { bad_login: "Tên hoặc mật khẩu chưa đúng.", too_many_attempts: "Bạn nhập sai quá nhiều lần. Hãy thử lại sau 10 phút.", unauthorized: "Phiên đăng nhập đã hết. Hãy đăng nhập lại.", forbidden: "Bạn không có quyền làm việc này.", weak_password: "Mật khẩu mới quá dễ đoán. Hãy dùng ít nhất 6 ký tự và đừng dùng 123456.", same_password: "Mật khẩu mới phải khác mật khẩu hiện tại (mật khẩu lớp cấp).", must_change_password: "Bạn cần đổi mật khẩu trước khi tiếp tục.", invalid: "Thông tin chưa hợp lệ.", no_r2: "Chưa gắn kho R2 trên Cloudflare nên chưa tải file nhạc được. Hãy dùng link YouTube.", bad_type: "Định dạng chưa hỗ trợ (nhạc: mp3, m4a, aac, ogg, wav; video: mp4, webm, mov).", too_big: "File quá lớn (nhạc tối đa 12 MB, video tối đa 60 MB). Video dài hãy đưa lên YouTube rồi dán link.", bad_video: "Chưa đúng. Hãy dán link YouTube hoặc gõ tên file (vd: khai-giang.mp4) đã bỏ trong thư mục web.", file_missing: "Chưa thấy file này trong thư mục web. Hãy bỏ file vào public/video, public/music hoặc public/img rồi đưa web lên lại.", bad_music: "Link nhạc chưa đúng. Hãy dán link YouTube hoặc tải file lên.", login_required: "Hãy đăng nhập để xem.", not_found: "Không tìm thấy." };
    return m[e && e.code] || (e && e.message) || "Có lỗi xảy ra.";
  };
  APP.ui = ui;

  /* ---------- ảnh đại diện dùng chung ---------- */
  var avP = null, bdP = null;
  APP.avatars = function (force) { if (!avP || force) avP = API.avatars().catch(function () { return {}; }); return avP; };
  /* ngày sinh là thông tin cá nhân: chỉ nạp khi đã đăng nhập. Khách => trả về false và MEMBERS không có ngày sinh */
  APP.loadBirthdays = function (force) {
    if (!API.user) { if (typeof applyBirthdays === "function") applyBirthdays([]); return Promise.resolve(false); }
    if (!bdP || force) bdP = API.birthdays().then(function (items) { applyBirthdays(items); return true; }).catch(function () { return false; });
    return bdP;
  };

  /* ---------- ảnh đại diện: tự đổi ảnh + lịch sử ảnh cũ ---------- */
  var pad2 = function (n) { return (n < 10 ? "0" : "") + n; };
  function dmy(iso) { var d = new Date(iso); return isNaN(d) ? "" : pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear(); }
  function fireAvatar(u) { document.dispatchEvent(new CustomEvent("avatar-change", { detail: u })); }
  APP.pickAvatar = function (username) {
    return ui.pick("image/*").then(function (fs) {
      if (!fs[0]) return false; ui.toast("Đang tải ảnh lên…");
      return API.img.process(fs[0]).then(function (r) { return API.setAvatar(username, r.thumb, r.full); })
        .then(function () { return APP.avatars(true); })
        .then(function () { ui.toast("Đã đổi ảnh ✓ Ảnh cũ được lưu ở mục “Ảnh cũ”"); fireAvatar(username); return true; })
        .catch(function (e) { ui.toast(ui.errText(e)); return false; });
    });
  };
  APP.avatarHistory = function (username, name) {
    var s = ui.sheet("Ảnh đại diện cũ", (name ? name + " · " : "") + "lưu 10 ảnh gần nhất. Chỉ chủ ảnh và người điều hành xem được.");
    var box = el("div", "ap-hist"); s.body.appendChild(box); box.innerHTML = '<p class="ap-note" style="grid-column:1/-1">Đang tải…</p>';
    function load() {
      API.avatarHistory(username).then(function (items) {
        box.innerHTML = "";
        if (!items.length) { box.innerHTML = '<p class="ap-note" style="grid-column:1/-1">Chưa có ảnh cũ nào. Mỗi lần đổi ảnh đại diện, ảnh trước đó sẽ được lưu ở đây để bạn dùng lại.</p>'; return; }
        items.forEach(function (h) {
          var c = el("div", "ap-h", '<img alt="Ảnh đại diện cũ"><small></small><div class="ap-hb"></div>');
          c.querySelector("img").src = h.thumb; c.querySelector("small").textContent = "Dùng đến " + dmy(h.replaced_at);
          c.querySelector("img").addEventListener("click", function () { ui.viewer({ thumb: h.thumb, alt: "Ảnh cũ", caption: "Ảnh cũ · dùng đến " + dmy(h.replaced_at), full: function () { return API.avatarHistoryFull(h.id); } }); });
          var use = el("button", "ap-btn sm", "Dùng lại"); use.type = "button";
          use.addEventListener("click", function () { use.disabled = true; API.restoreAvatar(h.id).then(function () { return APP.avatars(true); }).then(function () { ui.toast("Đã dùng lại ảnh cũ ✓"); fireAvatar(username); load(); }).catch(function (e) { use.disabled = false; ui.toast(ui.errText(e)); }); });
          var del = el("button", "ap-btn sm danger", "Xoá"); del.type = "button";
          del.addEventListener("click", function () { if (!confirm("Xoá hẳn ảnh cũ này?")) return; API.delAvatarHistory(h.id).then(load).catch(function (e) { ui.toast(ui.errText(e)); }); });
          c.querySelector(".ap-hb").appendChild(use); c.querySelector(".ap-hb").appendChild(del); box.appendChild(c);
        });
      }).catch(function (e) { box.innerHTML = '<p class="ap-err" style="grid-column:1/-1"></p>'; box.firstChild.textContent = ui.errText(e); });
    }
    load(); return s;
  };

  /* ---------- tìm người theo tên gõ vào ---------- */
  function findMember(txt) {
    var q = norm(txt); if (!q || typeof MEMBERS === "undefined") return null;
    var exact = MEMBERS.filter(function (m) { return norm(m.name) === q; }); if (exact.length === 1) return exact[0];
    var part = MEMBERS.filter(function (m) { return norm(m.name).indexOf(q) >= 0; }); return part.length === 1 ? part[0] : null;
  }

  /* ---------- đăng nhập (dùng chung cho hộp thoại và màn hình chào) ---------- */
  var CONTACT = "Lê Đức Anh hoặc Huỳnh Hữu Anh Khoa";
  function loginForm(b, onDone, autofocus) {
    if (!API.live) b.appendChild(el("div", "ap-note", "🧪 <b>Chế độ thử</b>: dữ liệu chỉ lưu trên máy này. Mật khẩu thử: <b>" + API.demoPass.member + "</b> (thành viên), <b>" + API.demoPass.admin + "</b> (người điều hành)."));
    var l1 = el("label", "ap-lab", "Tên của bạn"), inName = el("input", "ap-in");
    var uid = "n" + Math.random().toString(36).slice(2, 7); l1.setAttribute("for", "ap-name-" + uid); inName.id = "ap-name-" + uid; inName.setAttribute("list", "ap-names-" + uid); inName.placeholder = "Gõ hoặc chọn tên…"; inName.autocomplete = "off"; inName.setAttribute("autocapitalize", "words");
    var dl = el("datalist"); dl.id = "ap-names-" + uid; (typeof MEMBERS !== "undefined" ? MEMBERS : []).forEach(function (m) { var o = el("option"); o.value = m.name; dl.appendChild(o); });
    var l2 = el("label", "ap-lab", "Mật khẩu"); l2.setAttribute("for", "ap-pass-" + uid);
    var pw = el("div", "ap-pw"), inPass = el("input", "ap-in"); inPass.id = "ap-pass-" + uid; inPass.type = "password"; inPass.autocomplete = "current-password"; inPass.placeholder = "Mật khẩu";
    var eye = el("button", "ap-eye", "👁"); eye.type = "button"; eye.setAttribute("aria-label", "Hiện/ẩn mật khẩu"); eye.addEventListener("click", function () { inPass.type = inPass.type === "password" ? "text" : "password"; });
    pw.appendChild(inPass); pw.appendChild(eye);
    var err = el("p", "ap-err"); err.setAttribute("role", "alert");
    var go = el("button", "ap-btn", "Đăng nhập"); go.type = "button"; go.style.width = "100%"; go.style.marginTop = "6px";
    var hint = el("p", "ap-hint", "Chưa có mật khẩu? Hãy liên hệ <b>" + CONTACT.replace(" hoặc ", "</b> hoặc <b>") + "</b> để nhận mật khẩu.");
    [l1, inName, dl, l2, pw, err, go, hint].forEach(function (x) { b.appendChild(x); });
    function submit() {
      err.textContent = ""; var m = findMember(inName.value);
      if (!m) { err.textContent = "Hãy chọn đúng tên trong danh sách lớp."; inName.focus(); return; }
      if (!inPass.value) { err.textContent = "Hãy nhập mật khẩu."; inPass.focus(); return; }
      go.disabled = true; go.textContent = "Đang đăng nhập…";
      API.login(avatarSlug(m.name), inPass.value).then(function (u) { try { sessionStorage.removeItem("lop_guest"); } catch (e) {} ui.toast("Xin chào " + given(u.name) + "! 🌸"); onDone && onDone(u); })
        .catch(function (e) { err.textContent = ui.errText(e) + (e && e.code === "bad_login" ? " Chưa có mật khẩu? Hãy liên hệ " + CONTACT + "." : ""); go.disabled = false; go.textContent = "Đăng nhập"; inPass.select(); });
    }
    go.addEventListener("click", submit); inPass.addEventListener("keydown", function (e) { if (e.key === "Enter") submit(); }); inName.addEventListener("keydown", function (e) { if (e.key === "Enter") inPass.focus(); });
    if (autofocus) setTimeout(function () { inName.focus(); }, 350);
  }

  var loginOpen = null;
  APP.login = function () {
    if (loginOpen) return;
    var s = ui.sheet("Đăng nhập", "Chọn tên của bạn và nhập mật khẩu. Chỉ cần đăng nhập một lần, lần sau web tự nhớ trên máy này.");
    loginOpen = s; var oc = s.close; s.close = function () { loginOpen = null; oc(); };
    s.el.querySelector(".ap-x").addEventListener("click", function () { loginOpen = null; });
    s.el.addEventListener("click", function (e) { if (e.target === s.el) loginOpen = null; });
    loginForm(s.body, function (u) { loginOpen = null; s.close(); }, true);
  };

  /* ---------- màn hình chào: đăng nhập hoặc vào với tư cách khách ---------- */
  var gateEl = null;
  function closeGate() { if (!gateEl) return; var g = gateEl; gateEl = null; g.classList.remove("on"); lock(false); setTimeout(function () { g.remove(); }, 400); }
  APP.gate = function () {
    if (gateEl || API.user) return;
    var g = el("div", "ap-gate"), c = el("div", "ap-gate-card");
    g.setAttribute("role", "dialog"); g.setAttribute("aria-modal", "true"); g.setAttribute("aria-label", "Đăng nhập hoặc vào với tư cách khách");
    c.appendChild(el("div", "ap-gate-e", "🌸"));
    var h = el("h2"); h.textContent = "Chào mừng đến với lớp"; c.appendChild(h);
    var sub = el("p", "ap-gate-s"); sub.textContent = (typeof SITE !== "undefined" && SITE.school) ? SITE.school : "Kỉ niệm cấp 3"; c.appendChild(sub);
    loginForm(c, function () { closeGate(); }, false);
    c.appendChild(el("div", "ap-or", "<span>hoặc</span>"));
    var gb = el("button", "ap-btn ghost", "Vào xem với tư cách khách"); gb.type = "button"; gb.style.width = "100%";
    gb.addEventListener("click", function () { try { sessionStorage.setItem("lop_guest", "1"); } catch (e) {} closeGate(); ui.toast("Bạn đang xem với tư cách khách"); });
    c.appendChild(gb);
    c.appendChild(el("p", "ap-note", "👀 <b>Khách bị giới hạn:</b> chỉ xem được nội dung công khai (người điều hành chọn nội dung nào công khai), không xem được thông tin cá nhân như <b>ngày sinh</b> và <b>thư riêng</b>."));
    g.appendChild(c); document.body.appendChild(g); gateEl = g; lock(true); requestAnimationFrame(function () { g.classList.add("on"); });
  };
  APP.guestChosen = function () { try { return !!sessionStorage.getItem("lop_guest"); } catch (e) { return false; } };
  function maybeGate() { if (!API.user && !APP.guestChosen()) APP.gate(); }

  /* ---------- NHẮC đổi mật khẩu lớp cấp: có nút × / "Để sau" (không bắt buộc). Mỗi lần mở web mới nhắc lại một lần. ---------- */
  var forceEl = null, SNOOZE = "lop_pw_snooze";
  function snoozed() { try { return sessionStorage.getItem(SNOOZE) === "1"; } catch (e) { return false; } }
  function closeForce() { if (!forceEl) return; var g = forceEl; forceEl = null; g.classList.remove("on"); lock(false); document.removeEventListener("keydown", onEsc); setTimeout(function () { g.remove(); }, 400); }
  function onEsc(e) { if (e.key === "Escape") dismissReminder(); }
  function dismissReminder() { try { sessionStorage.setItem(SNOOZE, "1"); } catch (e) {} closeForce(); }
  APP.pwReminder = function () {
    var u = API.user; if (!u || forceEl) return;
    if (gateEl) closeGate();
    var g = el("div", "ap-gate"), c = el("div", "ap-gate-card");
    g.style.zIndex = 460; g.setAttribute("role", "dialog"); g.setAttribute("aria-modal", "true"); g.setAttribute("aria-label", "Nhắc đổi mật khẩu");
    var x = el("button", "ap-x", "✕"); x.type = "button"; x.setAttribute("aria-label", "Đóng, để sau");
    x.style.cssText = "position:absolute;top:10px;right:10px;width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,0,0,.06);color:inherit;font-size:17px;cursor:pointer;line-height:1";
    c.style.position = "relative"; c.appendChild(x);
    c.appendChild(el("div", "ap-gate-e", "🔐"));
    var h = el("h2"); h.textContent = "Hãy đổi mật khẩu của bạn"; c.appendChild(h);
    var sub = el("p", "ap-gate-s"); sub.textContent = "Chào " + given(u.name) + "! Mật khẩu hiện tại do lớp cấp nên nhiều người biết. Bạn nên đặt mật khẩu riêng để tài khoản an toàn. Chưa tiện thì cứ bấm ✕, lần sau mình sẽ nhắc lại."; c.appendChild(sub);
    function field(ph, ac) { var w = el("div"); w.style.marginTop = "10px"; var i = el("input", "ap-in"); i.type = "password"; i.placeholder = ph; i.autocomplete = ac; w.appendChild(i); c.appendChild(w); return i; }
    var o = field("Mật khẩu hiện tại (do lớp cấp)", "current-password"), n1 = field("Mật khẩu mới (từ 6 ký tự)", "new-password"), n2 = field("Nhập lại mật khẩu mới", "new-password");
    var eye = el("label", "ap-hint", ""); eye.style.cssText = "display:flex;gap:8px;align-items:center;margin-top:10px;cursor:pointer"; var cb = el("input"); cb.type = "checkbox";
    cb.addEventListener("change", function () { var t = cb.checked ? "text" : "password"; n1.type = t; n2.type = t; }); eye.appendChild(cb); eye.appendChild(document.createTextNode("Hiện mật khẩu mới")); c.appendChild(eye);
    var er = el("p", "ap-err"); er.setAttribute("role", "alert"); c.appendChild(er);
    var sv = el("button", "ap-btn", "Lưu mật khẩu mới"); sv.type = "button"; sv.style.cssText = "width:100%;margin-top:6px"; c.appendChild(sv);
    c.appendChild(el("p", "ap-hint", "Mật khẩu mới phải khác mật khẩu cũ. Đừng dùng 123456 hay ngày sinh."));
    var later = el("button", "ap-btn ghost", "Để sau"); later.type = "button"; later.style.cssText = "width:100%;margin-top:6px"; c.appendChild(later);
    function submit() {
      er.textContent = "";
      if (!o.value) { er.textContent = "Hãy nhập mật khẩu hiện tại (mật khẩu lớp đã cấp cho bạn)."; o.focus(); return; }
      if (n1.value.length < 6) { er.textContent = "Mật khẩu mới cần ít nhất 6 ký tự."; n1.focus(); return; }
      if (n1.value === o.value) { er.textContent = ui.errText({ code: "same_password" }); n1.focus(); return; }
      if (n1.value !== n2.value) { er.textContent = "Hai lần nhập chưa giống nhau."; n2.focus(); return; }
      sv.disabled = true; sv.textContent = "Đang lưu…";
      API.changePassword(o.value, n1.value).then(function () { ui.toast("Đã đổi mật khẩu ✓ Cảm ơn bạn!"); closeForce(); })
        .catch(function (e) { er.textContent = ui.errText(e); sv.disabled = false; sv.textContent = "Lưu mật khẩu mới"; });
    }
    sv.addEventListener("click", submit); [o, n1, n2].forEach(function (i) { i.addEventListener("keydown", function (e) { if (e.key === "Enter") submit(); }); });
    x.addEventListener("click", dismissReminder); later.addEventListener("click", dismissReminder);
    g.addEventListener("click", function (e) { if (e.target === g) dismissReminder(); });
    document.addEventListener("keydown", onEsc);
    g.appendChild(c); document.body.appendChild(g); forceEl = g; lock(true); requestAnimationFrame(function () { g.classList.add("on"); });
  };

  /* ---------- tài khoản ---------- */
  APP.account = function (forceChange) {
    var u = API.user; if (!u) { APP.login(); return; }
    var s = ui.sheet("Tài khoản"), b = s.body, adm = u.role === "admin";
    var me = el("div", "ap-me" + (adm ? " adm" : ""), '<div class="av"><span></span></div><div><b></b><br><span class="ap-badge' + (adm ? " adm" : "") + '"></span></div>');
    me.querySelector("span").textContent = initial(u.name); me.querySelector("b").textContent = u.name; me.querySelector(".ap-badge").textContent = adm ? "Người điều hành" : "Thành viên";
    me.querySelector("b").style.fontSize = "19px"; b.appendChild(me);
    function paintMe() { APP.avatars().then(function (map) { var a = map[u.username], old = me.querySelector(".av img"); if (old) old.remove(); if (a && a.t) { var im = el("img"); im.src = a.t; im.alt = ""; me.querySelector(".av").appendChild(im); } }); }
    paintMe();
    var rowAv = el("div", "ap-row");
    var bch = el("button", "ap-btn ghost", "📷 Đổi ảnh đại diện"); bch.type = "button"; bch.addEventListener("click", function () { APP.pickAvatar(u.username).then(function (ok) { if (ok) paintMe(); }); });
    var bhi = el("button", "ap-btn ghost", "🕘 Ảnh cũ"); bhi.type = "button"; bhi.addEventListener("click", function () { s.close(); APP.avatarHistory(u.username, u.name); });
    rowAv.appendChild(bch); rowAv.appendChild(bhi); b.appendChild(rowAv);
    if (u.avatar_ban_until) b.appendChild(el("div", "ap-note", "🚫 Bạn đang bị tạm cấm đổi ảnh đại diện đến " + new Date(u.avatar_ban_until).toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit", year: "numeric" }) + "."));
    if (u.must_change || forceChange) b.appendChild(el("div", "ap-note", "🔐 Mật khẩu của bạn do lớp cấp. Hãy đổi sang mật khẩu riêng để an toàn hơn."));
    var form = el("div"); form.style.display = (u.must_change || forceChange) ? "block" : "none";
    var o = el("input", "ap-in"), n1 = el("input", "ap-in"), n2 = el("input", "ap-in"), er = el("p", "ap-err"), sv = el("button", "ap-btn", "Lưu mật khẩu mới");
    [o, n1, n2].forEach(function (i) { i.type = "password"; i.autocomplete = "off"; }); o.placeholder = "Mật khẩu hiện tại"; n1.placeholder = "Mật khẩu mới (từ 6 ký tự)"; n2.placeholder = "Nhập lại mật khẩu mới"; sv.type = "button"; sv.style.width = "100%";
    [o, n1, n2].forEach(function (i) { var w = el("div"); w.style.marginTop = "10px"; w.appendChild(i); form.appendChild(w); }); form.appendChild(er); form.appendChild(sv); b.appendChild(form);
    sv.addEventListener("click", function () {
      er.textContent = ""; if (n1.value.length < 6) { er.textContent = "Mật khẩu mới cần ít nhất 6 ký tự."; return; } if (n1.value !== n2.value) { er.textContent = "Hai lần nhập chưa giống nhau."; return; }
      sv.disabled = true; API.changePassword(o.value, n1.value).then(function () { ui.toast("Đã đổi mật khẩu ✓"); s.close(); }).catch(function (e) { er.textContent = ui.errText(e); sv.disabled = false; });
    });
    var row = el("div", "ap-row");
    var bc = el("button", "ap-btn ghost", "🔑 Đổi mật khẩu"); bc.type = "button"; bc.addEventListener("click", function () { form.style.display = form.style.display === "none" ? "block" : "none"; if (form.style.display === "block") o.focus(); });
    row.appendChild(bc);
    if (adm) { var ba = el("a", "ap-btn ghost", "🛠 Quản trị"); ba.href = APP.base + "quan-tri.html"; row.appendChild(ba); }
    var bo = el("button", "ap-btn danger", "Đăng xuất"); bo.type = "button"; bo.addEventListener("click", function () { try { sessionStorage.removeItem("lop_guest"); } catch (e) {} API.logout().then(function () { s.close(); ui.toast("Đã đăng xuất"); }); }); row.appendChild(bo);
    b.appendChild(row);
  };

  /* ---------- nút tài khoản trên thanh trên + trong menu ---------- */
  var chip = null, drBlock = null, drAdm = null;
  function render() {
    var u = API.user, adm = API.isAdmin();
    var inner = document.querySelector(".snav-in"), btn = document.querySelector(".snav-btn");
    if (inner && btn) {
      if (!chip) { chip = el("button", "ap-chip"); chip.type = "button"; chip.addEventListener("click", function () { API.user ? APP.account() : APP.login(); }); inner.insertBefore(chip, btn); inner.style.justifyContent = "flex-start"; var br = inner.querySelector(".snav-brand"); if (br) br.style.marginRight = "auto"; }
      chip.className = "ap-chip" + (u ? " on" + (adm ? " adm" : "") : ""); chip.innerHTML = "";
      chip.setAttribute("aria-label", u ? "Tài khoản của " + u.name : "Đăng nhập");
      if (u) { var sp = el("span"); sp.textContent = initial(u.name); chip.appendChild(sp); chip.appendChild(el("i", "dot"));
        APP.avatars().then(function (map) { var a = map[u.username]; if (a && a.t && API.user === u && chip) { var im = el("img"); im.src = a.t; im.alt = ""; chip.insertBefore(im, chip.firstChild); } }); }
      else chip.textContent = "👤";
    }
    var dr = document.getElementById("site-drawer");
    if (dr) {
      if (!drBlock) { drBlock = el("div", "ap-dr"); var list = dr.querySelector(".dr-list"); dr.insertBefore(drBlock, list); }
      drBlock.className = "ap-dr" + (u ? " on" + (adm ? " adm" : "") : "");
      drBlock.innerHTML = '<div class="av"><span></span></div><div class="tx"><b></b><small></small></div>';
      var act = el("button", "ap-btn sm" + (u ? " ghost" : "")); act.type = "button"; act.textContent = u ? "Tài khoản" : "Đăng nhập"; act.addEventListener("click", function () { API.user ? APP.account() : APP.login(); });
      drBlock.querySelector("span").textContent = u ? initial(u.name) : "👤";
      drBlock.querySelector("b").textContent = u ? u.name : "Chưa đăng nhập";
      drBlock.querySelector("small").textContent = u ? (adm ? "Người điều hành" : "Thành viên") : "Đăng nhập để xem thư của bạn";
      drBlock.appendChild(act);
      if (u) APP.avatars().then(function (map) { var a = map[u.username]; if (a && a.t && API.user === u && drBlock) { var im = el("img"); im.src = a.t; im.alt = ""; var av = drBlock.querySelector(".av"); if (av && !av.querySelector("img")) av.appendChild(im); } });
      if (drAdm) { drAdm.remove(); drAdm = null; }
      if (adm) {
        var list2 = dr.querySelector(".dr-list"), li = el("li"); li.style.setProperty("--i", 9);
        li.innerHTML = '<a class="di" href="' + APP.base + 'quan-tri.html"><span class="ic">🛠</span><span class="tx"><b>Quản trị</b><small>Tạo sự kiện, đổi ảnh, viết thư</small></span><i class="ar">›</i></a>';
        list2.appendChild(li); drAdm = li;
      }
    }
    var banner = document.getElementById("ap-demo");
    if (API.modeKnown && !API.live && !banner && document.querySelector(".snav")) {
      banner = el("div", "", "🧪 Chế độ thử (chưa nối kho dữ liệu) — dữ liệu chỉ lưu trên máy này"); banner.id = "ap-demo";
      banner.style.cssText = "position:relative;text-align:center;font:700 12px ui-sans-serif,system-ui,sans-serif;padding:3px 8px;background:#fff1c9;color:#7a5a12;letter-spacing:.02em";
      var nav = document.querySelector(".snav"); nav.parentNode.insertBefore(banner, nav.nextSibling);
    }
  }
  document.addEventListener("avatar-change", function () { avP = null; render(); });
  API.on("auth", function () { avP = null; bdP = null; if (API.user && API.user.must_change && !snoozed()) APP.pwReminder(); else closeForce(); if (API.user) closeGate(); else maybeGate(); render(); document.dispatchEvent(new CustomEvent("auth-change", { detail: API.user })); });
  render();
  API.modeReady.then(function () { render(); });
})();
