/* =====================================================
   KẾT NỐI "KHO DỮ LIỆU" CHUNG (tài khoản, đăng nhập, sửa trên web)
   Khi web chạy trên Cloudflare Pages và đã gắn cơ sở dữ liệu D1 (xem HUONG-DAN-CAI-DAT.md),
   web tự nhận ra và chạy THẬT: dữ liệu dùng chung cho cả lớp.
   Nếu chưa gắn (hoặc mở file trực tiếp trên máy) web chạy CHẾ ĐỘ THỬ: dữ liệu chỉ lưu trong trình duyệt đó.
   ===================================================== */
const BACKEND = {
  api: "/api"      // đường dẫn tới phần máy chủ. Đặt "" để ép chạy chế độ thử.
};

/* Tài khoản người điều hành của CHẾ ĐỘ THỬ (khi chạy thật, vai trò nằm trong cơ sở dữ liệu) */
const DEMO_ADMINS = ["huynh-huu-anh-khoa", "le-duc-anh"];
