Bo anh (jpg, png, webp) vao day. Go ten file vao o "Anh va video trong bai" o trang Quan tri sau khi dua web len lai.
