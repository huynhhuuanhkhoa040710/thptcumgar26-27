/* =====================================================
   DANH SÁCH LỚP — sửa/thêm bạn ở đây
   gender: "f" = nữ, "m" = nam
   NGÀY SINH KHÔNG nằm trong file này nữa (là thông tin cá nhân). Ngày sinh được lưu trong cơ sở dữ liệu và chỉ thành viên đã đăng nhập mới xem được.
   Người điều hành nhập/sửa ở Quản trị → Tài khoản.
   role: "teacher" = cô giáo/thầy giáo (hiện khung riêng ở trang Thành viên, không tính vào số bạn)
   Ảnh đại diện KHÔNG lưu trong file: mỗi bạn tự đổi ảnh trên web (Tài khoản), người điều hành đổi giúp ở Quản trị → Ảnh đại diện. Chưa có ảnh thì hiện chữ cái đầu.
   Thứ tự ở đây = số thứ tự hiện trên web.
   ===================================================== */

const CLASSINFO = {
  className: "A3",
  course: "niên khoá 2025–2028",
  full: "A3 niên khoá 2025–2028",   // tên lớp hiển thị trên web
  school: "THPT Cư M’gar",
  showBirthYear: false  // false = chỉ hiện ngày/tháng sinh; true = hiện cả năm
};


/* tên đăng nhập của mỗi bạn = tên viết thường, bỏ dấu, thay khoảng trắng bằng dấu gạch ngang */
function avatarSlug(name){
  return name.replace(/đ/g,"d").replace(/Đ/g,"D").normalize("NFD").replace(/[\u0300-\u036f]/g,"")
    .toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
}
/* Nạp ngày sinh (lấy từ máy chủ sau khi đăng nhập) vào MEMBERS. items: [{u:"ten-dang-nhap", dob:"2010-03-15"|"05-12"}] */
function applyBirthdays(items) {
  var map = {}; (items || []).forEach(function (x) { map[x.u] = x.dob; });
  MEMBERS.forEach(function (m) { var d = map[avatarSlug(m.name)]; if (d) m.dob = d; else delete m.dob; });
}

const MEMBERS = [
  { name: "Nguyễn Thị Bích Liễu", gender: "f", role: "teacher", title: "Cô giáo" },
  { name: "Vương Thị Trần An", gender: "f" },
  { name: "Lê Đức Anh", gender: "m" },
  { name: "Nguyễn Hồ Ngọc Anh", gender: "f" },
  { name: "Văn Nguyễn Đức Ân", gender: "m" },
  { name: "Quách Tấn Dương", gender: "m" },
  { name: "Lê Huy Bảo", gender: "m" },
  { name: "Ngô Đức Đạo", gender: "m" },
  { name: "Nguyễn Minh Đức", gender: "m" },
  { name: "Nguyễn Thị Hồng Hà", gender: "f" },
  { name: "Trịnh Nguyễn Bảo Hiệp", gender: "m" },
  { name: "Trần Nguyễn Hoàng", gender: "m" },
  { name: "Nguyễn Minh Hùng", gender: "m" },
  { name: "Vũ Tuấn Hưng", gender: "m" },
  { name: "Nguyễn Quỳnh Hương", gender: "f" },
  { name: "Phạm Chí Khang", gender: "m" },
  { name: "Huỳnh Hữu Anh Khoa", gender: "m" },
  { name: "Phan Hoàng Lâm", gender: "m" },
  { name: "Đỗ Gia Linh", gender: "f" },
  { name: "Nguyễn Phạm Vy Ly", gender: "f" },
  { name: "Nguyễn Đặng Nhật Minh", gender: "m" },
  { name: "Huỳnh Hải Nam", gender: "m" },
  { name: "Lê Thanh Hưng", gender: "m" },
  { name: "Ngô Đinh Thảo Nguyên", gender: "f" },
  { name: "Phạm Trần Gia Như", gender: "f" },
  { name: "Trần Quốc Khánh", gender: "m" },
  { name: "Nguyễn Công Phát", gender: "m" },
  { name: "Lê Hồng Lâm", gender: "m" },
  { name: "Trịnh Thanh Phát", gender: "m" },
  { name: "Trần Ngọc Minh Quang", gender: "m" },
  { name: "Trần Bình Minh", gender: "m" },
  { name: "Trần Vương Quốc", gender: "m" },
  { name: "Nguyễn Lê Thục Quyên", gender: "f" },
  { name: "Nguyễn Hữu Trường Sơn", gender: "m" },
  { name: "Ngô Việt Tân", gender: "m" },
  { name: "Mai Lê Bảo Ngọc", gender: "f" },
  { name: "Mai Phương Thảo", gender: "f" },
  { name: "Lương Ngọc Tình", gender: "m" },
  { name: "Phan Nguyễn Huyền Trang", gender: "f" },
  { name: "Hồ Hà Trâm", gender: "f" },
  { name: "Ngô Quỳnh Trâm", gender: "f" },
  { name: "Nguyễn Thị Trâm", gender: "f" },
  { name: "Nguyễn Trần Thùy Trâm", gender: "f" },
  { name: "Tô Trần Bảo Thi", gender: "f" },
  { name: "Phạm Minh Tuấn", gender: "m" },
  { name: "Phan Anh Tuấn", gender: "m" },
  { name: "Hoàng Duy Hải Vương", gender: "m" },
  { name: "Phạm Nguyễn Triệu Vy", gender: "f" },
  { name: "Bùi Thị Như Ý", gender: "f" }
];

/* =====================================================
   DANH SÁCH CÁC LỚP TRƯỚC — dùng để so sánh "ai đi, ai mới" ở trang Khai giảng
   (danh sách lớp 10, năm học 2025–2026, theo bản của nhà trường)
   Mỗi dòng: ["Họ và tên"]
   ===================================================== */
const PREV_LISTS = {
  10: {
    year: "2025–2026",
    members: [
    ["Vương Thị Trần An"],
    ["Lê Đức Anh"],
    ["Văn Nguyễn Đức Ân"],
    ["Quách Tấn Dương"],
    ["Ngô Đức Đạo"],
    ["Nguyễn Minh Đức"],
    ["Nguyễn Thị Hồng Hà"],
    ["Trần Nguyễn Hoàng"],
    ["Nguyễn Minh Hùng"],
    ["Vũ Tuấn Hưng"],
    ["Nguyễn Quỳnh Hương"],
    ["Phạm Chí Khang"],
    ["Huỳnh Hữu Anh Khoa"],
    ["Phan Hoàng Lâm"],
    ["Đỗ Gia Linh"],
    ["Nguyễn Phạm Vy Ly"],
    ["Nguyễn Đặng Nhật Minh"],
    ["Huỳnh Hải Nam"],
    ["Ngô Đinh Thảo Nguyên"],
    ["Phạm Trần Gia Như"],
    ["Trần Quốc Khánh"],
    ["Trần Trịnh Thảo Ny"],
    ["Nguyễn Công Phát"],
    ["Trịnh Thanh Phát"],
    ["Trần Ngọc Minh Quang"],
    ["Trần Vương Quốc"],
    ["Nguyễn Lê Thục Quyên"],
    ["Nguyễn Hữu Trường Sơn"],
    ["Ngô Việt Tân"],
    ["Mai Phương Thảo"],
    ["Hà Ngọc Anh Thư"],
    ["Lương Ngọc Tình"],
    ["Phan Nguyễn Huyền Trang"],
    ["Ngô Quỳnh Trâm"],
    ["Nguyễn Thị Trâm"],
    ["Nguyễn Trần Thùy Trâm"],
    ["Phạm Minh Tuấn"],
    ["Phan Anh Tuấn"],
    ["Hoàng Duy Hải Vương"],
    ["Phạm Nguyễn Triệu Vy"],
    ["Trần Kiều Thảo Vy"],
    ["Bùi Thị Như Ý"],
    ["Nguyễn Phước Gia Khang"]
    ]
  }
};
