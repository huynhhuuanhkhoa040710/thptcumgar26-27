/* =====================================================
   DANH SÁCH SỰ KIỆN — chỉ cần sửa file này khi thêm sự kiện mới
   Mỗi sự kiện = 1 khối { ... } trong EVENTS bên dưới.
   Sảnh (index.html) tự đọc danh sách và hiển thị, không cần sửa gì khác.
   ===================================================== */

const SITE = {
  version: "2026-10-30.2",   // số phiên bản, hiện ở cuối menu để biết đang xem bản mới hay cũ
  title: "Ba năm cấp 3",
  subtitle: "Nơi giữ lại những ngày tụi mình đã cùng nhau đi qua.",
  school: "THPT Cư M’gar · Lớp A3 niên khoá 2025–2028",
  brand: "A3 niên khoá 2025–2028", // chữ nhỏ ở góc trái thanh menu
  cover: "assets/khai-giang.jpg",   // ảnh bìa ở SẢNH CHÍNH
  coverCaption: "Lễ khai giảng 2026 – 2027", // chữ dưới tấm ảnh polaroid ở sảnh
  coverAlt: "assets/khai-giang.jpg", // ảnh bìa của các trang con (Thành viên, Sinh nhật…)
  startDate: "",          // ngày nhập học, vd "2024-09-05" -> sảnh hiện "đã bên nhau N ngày"
  firstSchoolYear: 2025,  // năm học LỚP 10 bắt đầu (2025 = năm học 2025–2026) -> lớp 11 = 2026–2027, lớp 12 = 2027–2028
  schoolYearStartMonth: 9 // năm học bắt đầu từ tháng 9
};

/* =====================================================
   THANH MENU — thêm mục mới ở đây, mọi trang dùng chung
   soon:true = hiện mờ "Sắp có" (chưa bấm được)
   Khi làm xong một mục, đổi soon thành false và điền href.
   ===================================================== */
const MENU = [
  { label: "Trang chủ",  href: "index.html",          emoji: "🏠", desc: "Sảnh chính" },
  { label: "Sự kiện",    href: "index.html#su-kien",  emoji: "🎉", desc: "Những ngày đáng nhớ của lớp" },
  { label: "Thành viên", href: "members.html",        emoji: "👥", desc: "Danh sách lớp A3 niên khoá 2025–2028" },
  { label: "Sinh nhật",  href: "birthdays.html",      emoji: "🎂", desc: "Lịch sinh nhật của cả lớp" },
  { label: "Album lớp",  href: "album.html",   soon: true, emoji: "📷", desc: "Ảnh của cả lớp theo từng năm" },
  { label: "Thư sinh nhật", href: "thu-sinh-nhat.html", emoji: "💌", desc: "Thư riêng, mở ra đúng ngày sinh nhật của bạn" },
  { label: "Thư gửi tương lai", href: "letters.html", soon: true, emoji: "📮", desc: "Những lời nhắn mở ra sau này" }
];

const EVENTS = [
  {
    id: "05-09-2026",
    title: "Lễ khai giảng",
    date: "2026-09-05",
    emoji: "🎒",
    desc: "Cả lớp tụ họp, cùng mong chờ một năm học mới.",
    href: "events/05-09-2026/index.html",
    theme: "sun"
  },
  {
    id: "20-10-2026",
    title: "Thiệp 20/10",
    date: "2026-10-20",
    emoji: "🌸",
    desc: "Lời chúc chung gửi cô và các bạn nữ, kèm thiệp riêng cho từng bạn. Chọn tên để mở thiệp.",
    href: "events/20-10-2026/index.html",
    theme: "rose"        // rose | sky | mint | sun | lilac | sand
  }

  // ---- MẪU để thêm sự kiện mới: bỏ dấu // đầu mỗi dòng rồi sửa nội dung ----
  // ,{
  // id: "08-03-2027",
  // title: "Quốc tế Phụ nữ 8/3",
  // date: "2027-03-08",
  // emoji: "💐",
  // desc: "Mô tả ngắn 1 dòng.",
  // href: "events/08-03-2027/index.html",
  // theme: "lilac"
  // }
];
