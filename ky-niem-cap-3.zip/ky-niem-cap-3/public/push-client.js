// push-client.js — frontend: đăng ký service worker, subscribe push, chuông thông báo, form soạn (admin)
// Include vào trang: <script src="/push-client.js" defer></script>
// Yêu cầu có <link rel="manifest" href="/manifest.json"> trong <head>

(function () {
  'use strict';

  // ---- Lấy token đăng nhập ----
  // Token được lưu trong localStorage với key "lop_token" (xem api.js: var TK = "lop_token")
  // API.token là HÀM, phải gọi API.token()
  function getToken() {
    try {
      if (window.API && typeof API.token === 'function') { var t = API.token(); if (t) return t; }
      return localStorage.getItem('lop_token') || '';
    } catch { return ''; }
  }

  // ---- Tiện ích ----
  function urlB64ToUint8(base64url) {
    const pad = '='.repeat((4 - (base64url.length % 4)) % 4);
    const b64 = (base64url + pad).replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr;
  }

  function escapeHtml(s) {
    return (s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  // Lấy ID thông báo đã đọc cuối cùng (để đếm badge "chưa đọc")
  function getLastReadId() {
    try { return parseInt(localStorage.getItem('lop_last_read_notif') || '0', 10) || 0; }
    catch { return 0; }
  }
  function setLastReadId(id) {
    try { localStorage.setItem('lop_last_read_notif', String(id)); } catch {}
  }

  // ---- Lấy VAPID key từ server (có bắt lỗi) ----
  async function getVapidKey() {
    try {
      const r = await fetch('/app_vapid_public');
      if (!r.ok) return null;
      const j = await r.json();
      return j.publicKey || null;
    } catch { return null; }
  }

  // ---- Đăng ký service worker (chỉ 1 lần) ----
  let swReg = null;
  async function ensureSW() {
    if (swReg || !('serviceWorker' in navigator)) return swReg;
    try {
      swReg = await navigator.serviceWorker.register('/sw.js');
      return swReg;
    } catch { return null; }
  }

  // Lấy registration không bao giờ treo (dùng cache → getRegistration → ready có timeout)
  async function getSWReg() {
    if (swReg) return swReg;
    if (!('serviceWorker' in navigator)) return null;
    try {
      swReg = await navigator.serviceWorker.getRegistration();
      if (swReg) return swReg;
    } catch {}
    try {
      swReg = await Promise.race([
        navigator.serviceWorker.ready,
        new Promise(r => setTimeout(() => r(null), 3000)),
      ]);
    } catch {}
    return swReg;
  }

  // ---- Đăng ký nhận push ----
  async function subscribePush() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
      alert('Máy này chưa hỗ trợ thông báo.\nTrên iPhone: bấm Chia sẻ → "Thêm vào MH chính", rồi mở web từ biểu tượng đó và bật lại (cần iOS 16.4 trở lên).');
      return false;
    }
    if (Notification.permission === 'denied') { alert('Thông báo đang bị chặn. Hãy mở cài đặt của trình duyệt/ứng dụng và cho phép thông báo cho trang này.'); return false; }
    // Hỏi quyền NGAY khi bấm nút (iPhone yêu cầu phải nằm trong thao tác chạm)
    const perm = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
    if (perm !== 'granted') { alert('Bạn cần cho phép thông báo để nhận tin lớp.'); return false; }

    const reg = await ensureSW();
    if (!reg) { alert('Không đăng ký được service worker (/sw.js). Hãy kiểm tra web đã đưa lên đúng chưa.'); return false; }
    await Promise.race([navigator.serviceWorker.ready, new Promise(r => setTimeout(r, 6000))]);

    const vapid = await getVapidKey();
    if (!vapid) { alert('Không lấy được khoá thông báo từ máy chủ. Hãy mở /app_vapid_public để kiểm tra.'); return false; }
    const key = urlB64ToUint8(vapid);
    let sub = await reg.pushManager.getSubscription();
    if (sub) {
      // đăng ký cũ làm bằng khoá khác -> bỏ đi đăng ký lại
      const old = sub.options && sub.options.applicationServerKey ? new Uint8Array(sub.options.applicationServerKey) : null;
      if (old && (old.length !== key.length || old.some((v, i) => v !== key[i]))) { try { await sub.unsubscribe(); } catch (e) {} sub = null; }
    }
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
    const r = await fetch('/app_push_subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subscription: sub.toJSON(), p_token: getToken() }),
    });
    if (!r.ok) { alert('Máy chủ không nhận đăng ký thông báo (mã ' + r.status + ').'); return false; }
    return true;
  }

  // ---- Hủy đăng ký ----
  async function unsubscribePush() {
    if (!('serviceWorker' in navigator)) return;
    const reg = await getSWReg();
    if (!reg) return;
    const sub = await reg.pushManager.getSubscription();
    if (sub) {
      try { await sub.unsubscribe(); } catch {}
      try {
        await fetch('/app_push_unsubscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ endpoint: sub.endpoint }),
        });
      } catch {}
    }
  }

  // ---- UI: chuông thông báo ----
  async function loadBell() {
    const bell = document.getElementById('notifBell');
    if (!bell) return;

    let list = [];
    try {
      const r = await fetch('/app_notifications');
      const j = await r.json();
      list = j.notifications || [];
    } catch {}

    // Đếm thông báo CHƯA ĐỌC (id > lastReadId)
    const lastRead = getLastReadId();
    const unread = list.filter(n => n.id > lastRead).length;

    const badge = bell.querySelector('.badge');
    if (badge) {
      if (unread > 0) { badge.textContent = unread > 99 ? '99+' : String(unread); badge.style.display = ''; }
      else { badge.style.display = 'none'; }
    }

    const panel = document.getElementById('notifPanel');
    if (panel) {
      panel.innerHTML = list.length
        ? list.map(n => `
          <div class="notif-item" style="border-bottom:1px solid #eee;padding:8px 0;">
            <b>${escapeHtml(n.title)}</b>
            <p style="margin:4px 0;font-size:14px;">${escapeHtml(n.body)}</p>
            ${n.url ? `<a href="${escapeHtml(encodeURI(n.url))}" style="font-size:13px;">Mở</a>` : ''}
            <small style="display:block;color:#888;font-size:11px;">${new Date(n.created).toLocaleString('vi-VN')}</small>
          </div>`).join('')
        : '<p style="margin:0;color:#888;">Chưa có thông báo.</p>';
    }
  }

  // ---- Đánh dấu đã đọc khi mở panel ----
  function markAllRead(list) {
    if (list && list.length) setLastReadId(list[0].id); // list đã sắp xếp DESC → phần tử đầu là mới nhất
  }

  // ---- UI: form soạn thông báo (chỉ admin). Gửi theo từng đợt, tự lặp đến khi hết thiết bị ----
  async function setupAdminForm() {
    const form = document.getElementById('notifyForm');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = form.elements['title'].value.trim(), body = form.elements['body'].value.trim(), url = form.elements['url'].value.trim(), token = getToken();
      if (!token) { alert('Bạn cần đăng nhập admin trước khi gửi.'); return; }
      const btn = form.querySelector('button[type="submit"]') || form.querySelector('button');
      const label = btn.textContent; btn.disabled = true; btn.textContent = 'Đang gửi...';
      let id = 0, after = 0, sent = 0, fail = 0;
      try {
        for (let i = 0; i < 100; i++) {
          const r = await fetch('/app_admin_notify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title, body, url, id, after, p_token: token }) });
          const j = await r.json().catch(() => ({}));
          if (!j.ok) { alert('Lỗi: ' + (j.message || j.error || ('mã ' + r.status))); break; }
          id = j.id; after = j.after; sent += j.sent; fail += j.fail;
          btn.textContent = 'Đã gửi ' + sent + '…';
          if (j.done) { alert(sent || fail ? 'Đã gửi đến ' + sent + ' thiết bị' + (fail ? ' (' + fail + ' thiết bị lỗi/đã hết hạn)' : '') + '.' : 'Chưa có thiết bị nào bật thông báo.'); form.reset(); loadBell(); break; }
        }
      } catch (err) { alert('Lỗi gửi: ' + err.message); }
      btn.disabled = false; btn.textContent = label;
    });
  }

  // ---- Khởi tạo ----
  window.addEventListener('DOMContentLoaded', async () => {
    // Đăng ký service worker 1 lần duy nhất
    await ensureSW();

    // Tải chuông + form
    loadBell();
    setupAdminForm();

    // Chuông: bấm để mở/đóng panel + đánh dấu đã đọc
    const bell = document.getElementById('notifBell');
    const panel = document.getElementById('notifPanel');
    if (bell && panel) {
      bell.addEventListener('click', async () => {
        const isOpen = panel.style.display === 'block';
        panel.style.display = isOpen ? 'none' : 'block';
        if (!isOpen) {
          // Mở panel → tải lại + đánh dấu đã đọc
          await loadBell();
          try {
            const r = await fetch('/app_notifications');
            const j = await r.json();
            markAllRead(j.notifications || []);
            // Ẩn badge sau khi đã đọc
            const badge = bell.querySelector('.badge');
            if (badge) badge.style.display = 'none';
          } catch {}
        }
      });
    }

    // Nút bật/tắt nhận thông báo — gắn click NGAY, không chờ serviceWorker.ready
    // (nếu /sw.js chưa deploy, ready sẽ treo vĩnh viễn và làm nút không bấm được)
    const subBtn = document.getElementById('pushToggle');
    if (subBtn) {
      subBtn.addEventListener('click', async () => {
        subBtn.disabled = true;
        try {
          if (subBtn.dataset.state === 'on') {
            await unsubscribePush();
            subBtn.dataset.state = 'off'; subBtn.textContent = '🔔 Bật thông báo';
          } else {
            const ok = await subscribePush();
            if (ok) { subBtn.dataset.state = 'on'; subBtn.textContent = '🔕 Tắt thông báo'; }
          }
        } catch (e) {
          console.error('push toggle error', e);
          alert('Lỗi: ' + (e && e.message ? e.message : 'không xác định'));
        } finally {
          subBtn.disabled = false;
        }
      });
      // Kiểm tra subscription hiện có chạy nền, không chặn click handler
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready
          .then(reg => reg.pushManager.getSubscription())
          .then(existing => {
            if (existing) { subBtn.dataset.state = 'on'; subBtn.textContent = '🔕 Tắt thông báo'; }
          })
          .catch(() => {});
      }
    }
  });

  window.pushClient = { subscribePush, unsubscribePush, loadBell };
})();
