// Service Worker — PWA (chạy khi mất mạng) + nhận thông báo đẩy khi web đang đóng. Phải nằm ở GỐC web (/sw.js).
const CACHE = 'lop-a3-v2';

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(
  caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
));

// Ưu tiên mạng (luôn thấy bản mới nhất); mất mạng thì dùng bản đã xem gần nhất.
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== self.location.origin || /^\/(api|app_|media|video|music)/.test(u.pathname) || r.headers.has('range')) return;
  e.respondWith(
    fetch(r).then((res) => {
      if (res.ok && res.type === 'basic') { const c = res.clone(); caches.open(CACHE).then((ch) => ch.put(r, c)).catch(() => {}); }
      return res;
    }).catch(() => caches.match(r).then((m) => m || caches.match('/') || Response.error()))
  );
});

self.addEventListener('push', (event) => {
  let data = { title: 'Lớp A3', body: '', url: '/', tag: 'lop-a3' };
  if (event.data) {
    try { const p = event.data.json(); if (p && typeof p === 'object') Object.assign(data, p); }
    catch (e) { data.body = event.data.text() || 'Bạn có thông báo mới'; }
  }
  event.waitUntil(self.registration.showNotification(data.title || 'Lớp A3', {
    body: data.body || '', icon: '/icon-192.png', badge: '/icon-192.png',
    tag: data.tag || 'lop-a3', data: { url: data.url || '/' }, vibrate: [80, 40, 80],
  }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const abs = new URL((event.notification.data && event.notification.data.url) || '/', self.location.origin).href;
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    for (const c of list) {
      if (c.url.startsWith(self.location.origin) && 'focus' in c) {
        return c.focus().then((w) => (w && 'navigate' in w ? w.navigate(abs) : w)).catch(() => self.clients.openWindow(abs));
      }
    }
    return self.clients.openWindow(abs);
  }));
});

// Đăng ký thông báo hết hạn / đổi -> tự đăng ký lại
self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil((async () => {
    try {
      const j = await (await fetch('/app_vapid_public')).json();
      if (!j.publicKey) return;
      const pad = '='.repeat((4 - (j.publicKey.length % 4)) % 4), b = atob((j.publicKey + pad).replace(/-/g, '+').replace(/_/g, '/'));
      const key = Uint8Array.from(b, (c) => c.charCodeAt(0));
      const sub = await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
      await fetch('/app_push_subscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ subscription: sub.toJSON() }) });
    } catch (e) { /* bỏ qua */ }
  })());
});
