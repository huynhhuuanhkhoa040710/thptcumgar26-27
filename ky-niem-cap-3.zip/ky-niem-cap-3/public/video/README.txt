Bo file video (mp4, webm, mov) vao thu muc nay, moi file toi da 25 MB.
Sau do dua web len lai va go ten file vao o "Anh va video trong bai" o trang Quan tri.
Luu y: file trong thu muc nay AI CO DUONG DAN CUNG XEM DUOC. Dat ten kho doan (vd: k7x9-chuyen-di.mp4). Noi dung chi danh cho thanh vien thi dung YouTube khong cong khai.
