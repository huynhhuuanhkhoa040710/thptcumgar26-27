/* Thanh menu + ngăn kéo menu dùng chung cho mọi trang. Trang nào cũng chỉ cần:
   <div id="site-nav"></div>  +  <script src="(đường dẫn)/events.js"></script>  +  <script src="(đường dẫn)/site.js"></script>
   Các mục menu nằm trong MENU (events.js). */
(function(){
  var me=document.currentScript, base=me.src.replace(/site\.js(\?.*)?$/,'');
  /* nạp lớp tài khoản (config -> members -> api -> auth). Trang nào cần dữ liệu thì chờ APP.ready */
  var VER=(me.src.match(/[?&]v=([^&]+)/)||[])[1]||'';
  function ld(src){return new Promise(function(res){var s=document.createElement('script');s.src=base+src+(VER?'?v='+VER:'');s.onload=res;s.onerror=res;document.head.appendChild(s)})}
  window.APP=window.APP||{};APP.base=base;
  APP.ready=ld('config.js').then(function(){return typeof MEMBERS!=='undefined'?0:ld('members.js')})
    .then(function(){return ld('api.js')}).then(function(){return typeof API!=='undefined'?ld('auth.js'):0})
    .then(function(){return typeof API!=='undefined'?API.init():null});
  var css=`
  .snav{position:sticky;top:0;z-index:50;padding-top:env(safe-area-inset-top);background:rgba(255,252,246,.8);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid rgba(61,100,115,.14);font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
  .snav-in{width:min(100%,1040px);margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 14px}
  .snav-brand{min-width:0;overflow:hidden;text-overflow:ellipsis;font-family:"Times New Roman","Liberation Serif",serif;font-weight:700;font-size:17px;color:#243a40;text-decoration:none;white-space:nowrap}
  .snav-brand i{font-style:normal;color:#e58aa1;margin-right:5px}
  .snav-btn{display:inline-flex;align-items:center;gap:10px;min-height:44px;padding:8px 16px 8px 14px;border:1px solid rgba(47,102,201,.25);border-radius:999px;background:#fff;color:#1f3440;font:inherit;font-size:15px;font-weight:750;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .15s,box-shadow .2s}
  .snav-btn:active{transform:scale(.95)}
  .snav-btn:hover{box-shadow:0 6px 16px rgba(47,102,201,.18)}
  .burger{position:relative;width:20px;height:14px}
  .burger i{position:absolute;left:0;width:100%;height:2.5px;border-radius:2px;background:#2f66c9;transition:transform .3s,opacity .2s,top .3s}
  .burger i:nth-child(1){top:0}.burger i:nth-child(2){top:5.5px;width:70%}.burger i:nth-child(3){top:11px}
  .snav-btn[aria-expanded="true"] .burger i:nth-child(1){top:5.5px;transform:rotate(45deg)}
  .snav-btn[aria-expanded="true"] .burger i:nth-child(2){opacity:0}
  .snav-btn[aria-expanded="true"] .burger i:nth-child(3){top:5.5px;transform:rotate(-45deg)}
  .snav-btn:focus-visible,.snav-brand:focus-visible,.dr a:focus-visible,.dr button:focus-visible{outline:3px solid #377f8c;outline-offset:2px}

  .dr-bg{position:fixed;inset:0;z-index:90;background:rgba(14,32,70,.46);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);opacity:0;visibility:hidden;transition:opacity .3s,visibility 0s .3s}
  .dr{position:fixed;top:0;right:0;bottom:0;z-index:100;width:min(88vw,380px);display:flex;flex-direction:column;
    padding:calc(env(safe-area-inset-top) + 14px) 16px calc(env(safe-area-inset-bottom) + 16px);
    background:radial-gradient(ellipse at 100% 0%,#f8dfe6 0%,transparent 45%),radial-gradient(ellipse at 0% 100%,#d6e7f6 0%,transparent 50%),#fbf7ef;
    box-shadow:-18px 0 50px rgba(14,32,70,.28);border-radius:28px 0 0 28px;
    transform:translateX(105%);visibility:hidden;transition:transform .42s cubic-bezier(.2,.9,.25,1),visibility 0s .42s;
    font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#1f3440;overflow-y:auto}
  body.dr-open .dr-bg{opacity:1;visibility:visible;transition:opacity .3s}
  body.dr-open .dr{transform:none;visibility:visible;transition:transform .42s cubic-bezier(.2,.9,.25,1)}
  .dr-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}
  .dr-top b{font-family:"Times New Roman","Liberation Serif",serif;font-size:24px}
  .dr-top b i{font-style:normal;color:#e58aa1;margin-right:6px}
  .dr-x{width:44px;height:44px;border:0;border-radius:50%;background:rgba(255,255,255,.85);color:#1f3440;font-size:22px;line-height:1;cursor:pointer;box-shadow:0 3px 10px rgba(0,0,0,.08)}
  .dr-sub{margin:0 0 14px;font-size:13.5px;color:#5d7178}
  .dr-list{display:grid;gap:8px;margin:0;padding:0;list-style:none}
  .dr-list li{opacity:0;transform:translateX(26px)}
  body.dr-open .dr-list li{opacity:1;transform:none;transition:opacity .4s ease,transform .45s cubic-bezier(.2,.9,.3,1.1);transition-delay:calc(var(--i)*55ms + 120ms)}
  .di{display:flex;align-items:center;gap:14px;padding:12px 14px;border-radius:20px;border:1px solid rgba(255,255,255,.95);background:rgba(255,255,255,.78);color:inherit;text-decoration:none;box-shadow:0 4px 14px rgba(36,58,64,.06);transition:transform .2s,box-shadow .2s,background .2s}
  a.di:hover{transform:translateX(-3px);box-shadow:0 8px 20px rgba(47,102,201,.16)}
  a.di:active{transform:scale(.98)}
  .di .ic{flex:none;width:46px;height:46px;display:grid;place-items:center;border-radius:15px;background:linear-gradient(135deg,#fde4ea,#e0ebfb);font-size:24px}
  .di .tx{flex:1;min-width:0;display:flex;flex-direction:column;line-height:1.3}
  .di .tx b{font-size:16.5px;font-weight:750}
  .di .tx small{font-size:13px;color:#5d7178}
  .di .ar{flex:none;font-style:normal;font-size:22px;color:#9bb0b6}
  .di.on{background:linear-gradient(135deg,#3d78e0,#2f66c9);border-color:transparent;box-shadow:0 10px 24px rgba(47,102,201,.35);color:#fff}
  .di.on .ic{background:rgba(255,255,255,.22)}
  .di.on .tx small,.di.on .ar{color:rgba(255,255,255,.85)}
  .di.soon{opacity:.62;cursor:default;background:rgba(255,255,255,.5);border-style:dashed;border-color:rgba(47,102,201,.3);box-shadow:none}
  .di.soon em{flex:none;font-style:normal;font-size:10.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:3px 9px;border-radius:999px;background:rgba(47,102,201,.12);color:#2f66c9}
  .dr-foot{margin-top:auto;padding-top:20px;text-align:center;font-size:13px;color:#6f8088}
  .dr-foot span{display:block;font-family:"Times New Roman","Liberation Serif",serif;font-style:italic;font-size:16px;color:#4a6272;margin-bottom:2px}
  .snav-prog{position:absolute;left:0;right:0;bottom:-1px;height:3px;transform-origin:left;transform:scaleX(0);background:linear-gradient(90deg,#e58aa1,#f3c25f,#2f66c9);border-radius:0 3px 3px 0}
  .totop{position:fixed;right:16px;bottom:calc(18px + env(safe-area-inset-bottom));z-index:60;width:48px;height:48px;border:0;border-radius:50%;background:linear-gradient(135deg,#3d78e0,#2f66c9);color:#fff;font-size:22px;line-height:1;cursor:pointer;box-shadow:0 10px 24px rgba(47,102,201,.4);opacity:0;transform:translateY(18px) scale(.8);pointer-events:none;transition:opacity .3s,transform .3s;-webkit-tap-highlight-color:transparent}
  .totop.show{opacity:1;transform:none;pointer-events:auto}
  .totop:active{transform:scale(.92)}
  body.dr-open .totop{opacity:0;pointer-events:none}
  .totop:focus-visible{outline:3px solid #ffd9e3;outline-offset:3px}
  .fxsw{display:flex;align-items:center;justify-content:space-between;gap:12px;width:100%;margin-top:12px;padding:12px 14px;border:1px solid rgba(255,255,255,.95);border-radius:20px;background:rgba(255,255,255,.8);font:inherit;color:inherit;text-align:left;cursor:pointer;box-shadow:0 4px 14px rgba(36,58,64,.06);-webkit-tap-highlight-color:transparent}
  .fxsw .fxl{display:flex;align-items:center;gap:12px;min-width:0}
  .fxsw .fxl>i{flex:none;font-style:normal;font-size:22px;width:46px;height:46px;display:grid;place-items:center;border-radius:15px;background:linear-gradient(135deg,#fff1c9,#fde4ea)}
  .fxsw b{display:block;font-size:16.5px;font-weight:750;line-height:1.3}
  .fxsw small{display:block;font-size:12.5px;color:#5d7178;line-height:1.3}
  .fxsw .sw{flex:none;position:relative;width:52px;height:30px;border-radius:999px;background:#cbd5d9;transition:background .3s}
  .fxsw .sw em{position:absolute;left:3px;top:3px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.28);transition:transform .3s cubic-bezier(.2,.9,.3,1.2)}
  .fxsw[aria-checked="true"] .sw{background:linear-gradient(135deg,#3d78e0,#2f66c9)}
  .fxsw[aria-checked="true"] .sw em{transform:translateX(22px)}
  .fxsw:focus-visible{outline:3px solid #377f8c;outline-offset:2px}
  .dr-foot small{display:block;margin-top:4px;font-size:11.5px;opacity:.75}
  html[data-fx="off"] .dr,html[data-fx="off"] .dr-bg,html[data-fx="off"] .dr-list li,html[data-fx="off"] .burger i,html[data-fx="off"] .totop,html[data-fx="off"] .fxsw .sw,html[data-fx="off"] .fxsw .sw em{transition:none!important}`;
  var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

  var host=document.getElementById('site-nav'); if(!host||typeof MENU==='undefined')return;
  function el(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e}

  /* thanh trên */
  var nav=el('nav','snav');nav.setAttribute('aria-label','Menu chính');
  var inner=el('div','snav-in');
  var brand=el('a','snav-brand','<i>✦</i>');brand.href=base+'index.html';
  brand.appendChild(document.createTextNode((typeof SITE!=='undefined'&&SITE.brand)||'Kỉ niệm'));
  var btn=el('button','snav-btn','<span class="burger" aria-hidden="true"><i></i><i></i><i></i></span><span>Menu</span>');
  btn.type='button';btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-controls','site-drawer');btn.setAttribute('aria-label','Mở menu');
  inner.appendChild(brand);inner.appendChild(btn);nav.appendChild(inner);host.appendChild(nav);

  /* ngăn kéo (gắn vào body để không bị kẹt trong thanh dính) */
  var bg=el('div','dr-bg');bg.setAttribute('aria-hidden','true');
  var dr=el('aside','dr');dr.id='site-drawer';dr.setAttribute('role','dialog');dr.setAttribute('aria-modal','true');dr.setAttribute('aria-label','Menu');
  var top=el('div','dr-top','<b><i>✦</i>Menu</b>');
  var x=el('button','dr-x','✕');x.type='button';x.setAttribute('aria-label','Đóng menu');top.appendChild(x);
  var sub=el('p','dr-sub');sub.textContent=(typeof SITE!=='undefined'&&SITE.school)||'';
  var list=el('ul','dr-list');
  var path=location.pathname;
  var items=[];
  MENU.forEach(function(m,i){
    var li=el('li');li.style.setProperty('--i',i);var a;
    if(m.soon){
      a=el('div','di soon','<span class="ic"></span><span class="tx"><b></b><small></small></span><em>Sắp có</em>');a.setAttribute('aria-disabled','true');
    }else{
      a=el('a','di','<span class="ic"></span><span class="tx"><b></b><small></small></span><i class="ar">›</i>');a.href=base+m.href;
    }
    a.querySelector('.ic').textContent=m.emoji||'✨';
    a.querySelector('b').textContent=m.label;
    a.querySelector('small').textContent=m.desc||'';
    li.appendChild(a);list.appendChild(li);items.push({m:m,a:a});
  });
  var fxOn=document.documentElement.getAttribute('data-fx')!=='off';
  var fx=el('button','fxsw','<span class="fxl"><i aria-hidden="true">✨</i><span><b>Hiệu ứng</b><small></small></span></span><span class="sw" aria-hidden="true"><em></em></span>');
  fx.type='button';fx.setAttribute('role','switch');fx.setAttribute('aria-checked',String(fxOn));
  fx.querySelector('small').textContent=fxOn?'Đang bật · chạm để tắt':'Đang tắt · chạm để bật';
  fx.addEventListener('click',function(){
    var next=document.documentElement.getAttribute('data-fx')==='off'?'on':'off',saved=false;
    try{localStorage.setItem('fx',next);saved=localStorage.getItem('fx')===next}catch(e){}
    if(saved){location.reload()}
    else{var u=location.search.replace(/([?&])fx=(on|off)&?/,'$1').replace(/[?&]$/,'');location.search=(u?u+'&':'?')+'fx='+next}
  });
  var foot=el('div','dr-foot','<span>Rồi mỗi đứa một ngả, nhưng kỉ niệm thì ở lại.</span>');
  foot.appendChild(document.createTextNode('Kỉ niệm cấp 3 ✦'));
  if(typeof SITE!=='undefined'&&SITE.version){var vs=el('small');vs.textContent='Phiên bản '+SITE.version;foot.appendChild(vs)}
  dr.appendChild(top);if(sub.textContent)dr.appendChild(sub);dr.appendChild(list);dr.appendChild(fx);dr.appendChild(foot);
  document.body.appendChild(bg);document.body.appendChild(dr);

  /* mục đang xem */
  function setActive(){
    var p=location.pathname,h=location.hash;
    var home=/(^|\/)index\.html$/.test(p)||/\/$/.test(p);
    var inEvents=p.indexOf('/events/')>=0;
    items.forEach(function(o){
      if(o.m.soon)return;
      var f=o.m.href.split('#')[0],hh=o.m.href.indexOf('#')>=0?'#'+o.m.href.split('#')[1]:'',on=false;
      if(hh){on=home&&!inEvents&&h===hh}
      else if(f==='index.html'){on=home&&!inEvents&&!h}
      else{on=p.slice(-f.length)===f}
      o.a.classList.toggle('on',on);
      if(on)o.a.setAttribute('aria-current','page');else o.a.removeAttribute('aria-current');
    });
    /* đang ở trang thiệp trong thư mục events -> làm sáng "Sự kiện" */
    if(inEvents){items.forEach(function(o){if(!o.m.soon&&o.m.href.indexOf('#su-kien')>=0){o.a.classList.add('on')}})}
  }
  setActive();window.addEventListener('hashchange',setActive);

  /* thanh tiến độ cuộn + nút lên đầu trang */
  var reduceM=document.documentElement.getAttribute('data-fx')==='off';
  var prog=el('div','snav-prog');prog.setAttribute('aria-hidden','true');nav.appendChild(prog);
  var upBtn=el('button','totop','↑');upBtn.type='button';upBtn.setAttribute('aria-label','Lên đầu trang');document.body.appendChild(upBtn);
  var tk=false;
  function onSc(){if(tk)return;tk=true;requestAnimationFrame(function(){tk=false;
    var h=document.documentElement.scrollHeight-window.innerHeight,y=window.scrollY;
    prog.style.transform='scaleX('+(h>0?Math.min(1,y/h):0)+')';upBtn.classList.toggle('show',y>700)})}
  window.addEventListener('scroll',onSc,{passive:true});window.addEventListener('resize',onSc);onSc();
  upBtn.addEventListener('click',function(){window.scrollTo({top:0,behavior:reduceM?'auto':'smooth'})});

  /* mở / đóng */
  var isOpen=false;
  function open(){isOpen=true;document.body.classList.add('dr-open');document.documentElement.style.overflow='hidden';
    btn.setAttribute('aria-expanded','true');btn.setAttribute('aria-label','Đóng menu');setTimeout(function(){var f=dr.querySelector('a.di');(f||x).focus()},60)}
  function close(back){isOpen=false;document.body.classList.remove('dr-open');document.documentElement.style.overflow='';
    btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-label','Mở menu');if(back!==false)btn.focus()}
  btn.addEventListener('click',function(){isOpen?close():open()});
  x.addEventListener('click',function(){close()});
  bg.addEventListener('click',function(){close()});
  list.addEventListener('click',function(e){if(e.target.closest('a.di'))close(false)});
  document.addEventListener('keydown',function(e){
    if(!isOpen)return;
    if(e.key==='Escape'){close();return}
    if(e.key==='Tab'){var f=[].slice.call(dr.querySelectorAll('a.di,button')).filter(function(n){return n.offsetParent!==null});
      if(!f.length)return;var first=f[0],last=f[f.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
  });
})();

/* Trình phát nhạc nhỏ: APP.music(chỗ_gắn, {kind:'file',src,title} | {kind:'yt',id,title}, {autoplay})
   Trình duyệt chỉ cho phát sau khi người xem chạm, nên mặc định phải bấm ▶. */
(function(){
  window.APP=window.APP||{};var cur=null;APP.pauseMusic=function(){if(cur)cur.pause()};
  APP.music=function(mount,m,o){
    if(!mount||!m)return null;o=o||{};
    var box=document.createElement('div');box.className='mus';
    box.style.cssText='display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:12px auto;padding:8px 16px 8px 8px;max-width:460px;border-radius:24px;background:rgba(255,255,255,.95);color:#1f2a44;box-shadow:0 6px 18px rgba(20,42,82,.18);font:600 14px/1.3 system-ui,-apple-system,"Segoe UI",sans-serif;text-align:left';
    var b=document.createElement('button');b.type='button';b.setAttribute('aria-label','Phát nhạc');b.textContent='▶';
    b.style.cssText='flex:none;width:42px;height:42px;border:0;border-radius:50%;background:linear-gradient(135deg,#3d78e0,#2f66c9);color:#fff;font-size:17px;cursor:pointer';
    var t=document.createElement('span');t.style.cssText='flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';t.textContent='🎵 '+(m.title||'Nhạc nền');
    box.appendChild(b);box.appendChild(t);mount.appendChild(box);
    var audio=null,frame=null,on=false,ctl={box:box};
    function ui(){b.textContent=on?'⏸':'▶';b.setAttribute('aria-label',on?'Dừng nhạc':'Phát nhạc')}
    ctl.play=function(){
      if(on)return;if(cur&&cur!==ctl)cur.pause();cur=ctl;on=true;ui();
      if(m.kind==='yt'){
        frame=document.createElement('iframe');
        frame.src='https://www.youtube-nocookie.com/embed/'+encodeURIComponent(m.id)+'?autoplay=1&loop=1&playlist='+encodeURIComponent(m.id)+'&playsinline=1&rel=0';
        frame.allow='autoplay; encrypted-media; picture-in-picture';frame.title=m.title||'Nhạc nền';
        frame.style.cssText='flex-basis:100%;width:100%;aspect-ratio:16/9;border:0;border-radius:14px;background:#000';box.appendChild(frame);
      }else{
        if(!audio){audio=new Audio();audio.src=m.src;audio.loop=true;audio.preload='none'}
        var p=audio.play();if(p&&p.catch)p.catch(function(){on=false;ui();if(APP.ui&&APP.ui.toast)APP.ui.toast('Không phát được nhạc. Hãy thử chạm ▶ lần nữa.')});
      }
    };
    ctl.pause=function(){
      if(!on)return;on=false;ui();if(cur===ctl)cur=null;
      if(audio)audio.pause();if(frame){frame.remove();frame=null}
    };
    b.addEventListener('click',function(e){e.stopPropagation();on?ctl.pause():ctl.play()});
    if(o.autoplay)ctl.play();
    return ctl;
  };
})();

/* Danh sách video: APP.videos(chỗ_gắn, [{kind:'file',src,title} | {kind:'yt',id,title}], {preload})
   Trả về { stop(), start() } — stop() dừng hết (dùng khi gấp thư), start() nạp lại khung YouTube. */
(function(){
  window.APP=window.APP||{};
  APP.videos=function(mount,list,o){
    if(!mount||!list||!list.length)return null;o=o||{};
    var wrap=document.createElement('div');wrap.style.cssText='display:grid;gap:16px;margin:14px 0';
    var frames=[],vids=[];
    list.forEach(function(v){
      var fig=document.createElement('figure');fig.style.cssText='margin:0';var box;
      if(v.kind==='yt'){
        box=document.createElement('iframe');box.dataset.src='https://www.youtube-nocookie.com/embed/'+encodeURIComponent(v.id)+'?rel=0&playsinline=1';
        box.src=box.dataset.src;box.loading='lazy';box.title=v.title||'Video';box.allow='accelerometer; encrypted-media; picture-in-picture; fullscreen';box.allowFullscreen=true;
        box.style.cssText='display:block;width:100%;aspect-ratio:16/9;border:0;border-radius:16px;background:#000';frames.push(box);
      }else{
        box=document.createElement('video');box.controls=true;box.setAttribute('playsinline','');box.preload=o.preload||'metadata';box.src=v.src+(o.preload==='none'?'':'#t=0.1');
        box.style.cssText='display:block;width:100%;max-height:75vh;border-radius:16px;background:#000';
        box.addEventListener('play',function(){if(APP.pauseMusic)APP.pauseMusic();vids.forEach(function(x){if(x!==box)x.pause()})});vids.push(box);
      }
      fig.appendChild(box);
      if(v.title){var cp=document.createElement('figcaption');cp.textContent=v.title;cp.style.cssText='margin-top:6px;font:600 13px/1.4 system-ui,sans-serif;opacity:.8;text-align:center';fig.appendChild(cp)}
      wrap.appendChild(fig);
    });
    mount.appendChild(wrap);
    return{el:wrap,
      stop:function(){vids.forEach(function(x){x.pause()});frames.forEach(function(f){f.src='about:blank'})},
      start:function(){frames.forEach(function(f){if(f.getAttribute('src')==='about:blank')f.src=f.dataset.src})}};
  };
})();

/* Nội dung có ảnh/video chèn giữa bài.
   APP.richBody(chỗ_gắn, văn_bản, media, {single, preload})
   Trong văn bản, [[m:KHOÁ]] là vị trí của một ảnh/video; media chưa được chèn sẽ nằm cuối bài.
   media = [{k, kind:'img'|'file'|'yt', src|id, title}]. Trả về { stop(), start() } (dùng khi gấp/mở thư). */
(function(){
  window.APP=window.APP||{};
  APP.richBody=function(mount,text,media,o){
    o=o||{};var vids=[],frames=[],map={},used={};
    (media||[]).forEach(function(m){if(m&&m.k)map[m.k]=m});
    function block(m){
      var fig=document.createElement('figure');fig.style.cssText='margin:16px 0;white-space:normal';var box;
      if(m.kind==='yt'){
        box=document.createElement('iframe');box.dataset.src='https://www.youtube-nocookie.com/embed/'+encodeURIComponent(m.id)+'?rel=0&playsinline=1';
        box.src=box.dataset.src;box.loading='lazy';box.title=m.title||'Video';box.allow='accelerometer; encrypted-media; picture-in-picture; fullscreen';box.allowFullscreen=true;
        box.style.cssText='display:block;width:100%;aspect-ratio:16/9;border:0;border-radius:16px;background:#000';frames.push(box);
      }else if(m.kind==='img'){
        box=document.createElement('img');box.src=m.src;box.alt=m.title||'Ảnh';box.loading='lazy';
        box.style.cssText='display:block;width:100%;height:auto;border-radius:16px;cursor:zoom-in;background:rgba(0,0,0,.05)';
        box.addEventListener('click',function(){if(APP.ui&&APP.ui.viewer)APP.ui.viewer({thumb:m.src,alt:m.title||'',caption:m.title||'',full:function(){return Promise.resolve(m.src)}})});
      }else{
        box=document.createElement('video');box.controls=true;box.setAttribute('playsinline','');box.preload=o.preload||'metadata';box.src=m.src+(o.preload==='none'?'':'#t=0.1');
        box.style.cssText='display:block;width:100%;max-height:75vh;border-radius:16px;background:#000';
        box.addEventListener('play',function(){if(APP.pauseMusic)APP.pauseMusic();vids.forEach(function(x){if(x!==box)x.pause()})});vids.push(box);
      }
      fig.appendChild(box);
      if(m.title){var cp=document.createElement('figcaption');cp.textContent=m.title;cp.style.cssText='margin-top:6px;font:600 13px/1.4 system-ui,sans-serif;opacity:.8;text-align:center';fig.appendChild(cp)}
      return fig;
    }
    function paras(t){
      if(o.single){if(t.replace(/\s+/g,'')){var p=document.createElement('p');p.textContent=t.replace(/^\n+|\n+$/g,'');mount.appendChild(p)}return}
      t.split(/\n{2,}/).forEach(function(x){x=x.trim();if(!x)return;var p=document.createElement('p');p.textContent=x;mount.appendChild(p)});
    }
    String(text||'').split(/\[\[m:([\w-]{1,12})\]\]/).forEach(function(seg,i){
      if(i%2===0)paras(seg);else if(map[seg]&&!used[seg]){used[seg]=1;mount.appendChild(block(map[seg]))}
    });
    (media||[]).forEach(function(m){if(m&&m.k&&!used[m.k]){used[m.k]=1;mount.appendChild(block(m))}});
    return{
      stop:function(){vids.forEach(function(x){x.pause()});frames.forEach(function(f){f.src='about:blank'})},
      start:function(){frames.forEach(function(f){if(f.getAttribute('src')==='about:blank')f.src=f.dataset.src})}
    };
  };
})();
