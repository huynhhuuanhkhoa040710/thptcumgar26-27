// ============================================================
// push.js — Web Push cho Cloudflare Workers. KHÔNG cần thư viện ngoài (chỉ dùng WebCrypto).
// - Khoá VAPID: tự sinh và lưu trong D1 ở lần đầu. Muốn dùng khoá riêng thì đặt biến VAPID_PUBLIC_KEY + VAPID_PRIVATE_KEY.
// - Gửi theo từng đợt ~40 thiết bị để không vượt giới hạn số lần gọi của Cloudflare (giao diện tự lặp).
// ============================================================
import { b64uEnc, b64uDec, getSetting, setSettingOnce } from "./media.js";

const enc = new TextEncoder();
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
const BATCH = 40;

/* ---------- bảng ---------- */
let tablesReady = null;
function ensureTables(env) {
  if (!tablesReady) tablesReady = (async () => {
    await env.DB.batch([
      env.DB.prepare("CREATE TABLE IF NOT EXISTS push_subscriptions (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, endpoint TEXT NOT NULL, p256dh TEXT NOT NULL, auth TEXT NOT NULL, created TEXT)"),
      env.DB.prepare("CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, url TEXT, created TEXT, sent_count INTEGER DEFAULT 0, fail_count INTEGER DEFAULT 0)"),
    ]);
    /* bảng bạn đã tự tạo trước đó có thể thiếu cột -> bổ sung (đã có thì bỏ qua) */
    for (const sql of ["ALTER TABLE push_subscriptions ADD COLUMN username TEXT", "ALTER TABLE push_subscriptions ADD COLUMN created TEXT", "ALTER TABLE notifications ADD COLUMN sent_count INTEGER DEFAULT 0", "ALTER TABLE notifications ADD COLUMN fail_count INTEGER DEFAULT 0", "ALTER TABLE notifications ADD COLUMN url TEXT"]) {
      try { await env.DB.prepare(sql).run(); } catch (e) { if (!/duplicate column|already exists/i.test(String(e && e.message || e))) throw e; }
    }
  })().catch(e => { tablesReady = null; throw e; });
  return tablesReady;
}

/* ---------- khoá VAPID ---------- */
let vapidCache = null;
async function getVapid(env) {
  if (vapidCache) return vapidCache;
  let pub, d;
  if (env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY) { pub = env.VAPID_PUBLIC_KEY.trim(); d = env.VAPID_PRIVATE_KEY.trim(); }
  else {
    let s = await getSetting(env, "vapid");
    if (!s) {
      const kp = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
      const jwk = await crypto.subtle.exportKey("jwk", kp.privateKey);
      const raw = new Uint8Array(65); raw[0] = 4; raw.set(b64uDec(jwk.x), 1); raw.set(b64uDec(jwk.y), 33);
      s = await setSettingOnce(env, "vapid", JSON.stringify({ pub: b64uEnc(raw), d: jwk.d }));
    }
    ({ pub, d } = JSON.parse(s));
  }
  const raw = b64uDec(pub);
  const key = await crypto.subtle.importKey("jwk", { kty: "EC", crv: "P-256", d, x: b64uEnc(raw.slice(1, 33)), y: b64uEnc(raw.slice(33, 65)), ext: true }, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  return (vapidCache = { pub, key });
}
async function vapidHeader(env, endpoint, subject) {
  const { pub, key } = await getVapid(env);
  const h = b64uEnc(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const c = b64uEnc(enc.encode(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject })));
  const sig = new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(h + "." + c)));
  return "vapid t=" + h + "." + c + "." + b64uEnc(sig) + ", k=" + pub;
}

/* ---------- mã hoá nội dung (RFC 8291, aes128gcm) ---------- */
const concat = (...a) => { const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let p = 0; for (const x of a) { o.set(x, p); p += x.length; } return o; };
async function hkdf(salt, ikm, info, len) {
  const k = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-256", salt, info }, k, len * 8));
}
export async function encryptPayload(p256dhB64, authB64, text) {
  const uaPub = b64uDec(p256dhB64), authSecret = b64uDec(authB64);
  const uaKey = await crypto.subtle.importKey("raw", uaPub, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const eph = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const asPub = new Uint8Array(await crypto.subtle.exportKey("raw", eph.publicKey));
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: uaKey }, eph.privateKey, 256));
  const ikm = await hkdf(authSecret, shared, concat(enc.encode("WebPush: info\0"), uaPub, asPub), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  const nonce = await hkdf(salt, ikm, enc.encode("Content-Encoding: nonce\0"), 12);
  const aes = await crypto.subtle.importKey("raw", cek, "AES-GCM", false, ["encrypt"]);
  const data = concat(enc.encode(text), new Uint8Array([2]));        // 0x02 = bản ghi cuối
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, aes, data));
  return concat(salt, new Uint8Array([0, 0, 0x10, 0]), new Uint8Array([65]), asPub, ct);   // rs = 4096
}
async function sendOne(env, sub, payload, subject) {
  const body = await encryptPayload(sub.p256dh, sub.auth, payload);
  const r = await fetch(sub.endpoint, { method: "POST", headers: { "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", "TTL": "86400", "Urgency": "normal", "Authorization": await vapidHeader(env, sub.endpoint, subject) }, body });
  return r.status;
}

/* ---------- các đường dẫn ---------- */
export async function handlePush(request, env, who) {
  const url = new URL(request.url), path = url.pathname;
  if (!path.startsWith("/app_")) return null;
  if (!env.DB) return json({ error: "no_db" }, 503);
  try {
    await ensureTables(env);
    const body = request.method === "POST" ? await request.json().catch(() => ({})) : {};
    const bearer = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    const user = await who(env, body.p_token || bearer || url.searchParams.get("t") || "");

    if (path === "/app_vapid_public" && request.method === "GET") return json({ publicKey: (await getVapid(env)).pub });

    if (path === "/app_push_subscribe" && request.method === "POST") {
      const s = body.subscription;
      if (!s || typeof s.endpoint !== "string" || !s.endpoint.startsWith("https://") || s.endpoint.length > 1000 || !s.keys || !s.keys.p256dh || !s.keys.auth) return json({ error: "invalid subscription" }, 400);
      await env.DB.batch([
        env.DB.prepare("DELETE FROM push_subscriptions WHERE endpoint = ?").bind(s.endpoint),
        env.DB.prepare("INSERT INTO push_subscriptions (username, endpoint, p256dh, auth, created) VALUES (?, ?, ?, ?, ?)").bind(user ? user.username : null, s.endpoint, s.keys.p256dh, s.keys.auth, new Date().toISOString()),
      ]);
      return json({ ok: true });
    }
    if (path === "/app_push_unsubscribe" && request.method === "POST") {
      if (body.endpoint) await env.DB.prepare("DELETE FROM push_subscriptions WHERE endpoint = ?").bind(String(body.endpoint)).run();
      return json({ ok: true });
    }
    if (path === "/app_notifications" && request.method === "GET") {
      if (!user) return json({ notifications: [] });
      const { results } = await env.DB.prepare("SELECT id, title, body, url, created FROM notifications ORDER BY id DESC LIMIT 50").all();
      return json({ notifications: results || [] });
    }
    if (path === "/app_admin_notify" && request.method === "POST") {
      if (!user || user.role !== "admin") return json({ error: "admin only" }, 403);
      const title = String(body.title || "").trim().slice(0, 100), text = String(body.body || "").trim().slice(0, 400);
      let link = String(body.url || "").trim().slice(0, 500) || "/";
      if (/^https?:\/\//i.test(link)) { try { const u = new URL(link); link = u.origin === url.origin ? u.pathname + u.search + u.hash : "/"; } catch (e) { link = "/"; } }
      else if (!link.startsWith("/")) link = "/";
      let id = Number(body.id) || 0, after = Number(body.after) || 0;
      if (!id) {
        if (!title || !text) return json({ error: "title & body required" }, 400);
        id = (await env.DB.prepare("INSERT INTO notifications (title, body, url, created, sent_count, fail_count) VALUES (?, ?, ?, ?, 0, 0)").bind(title, text, link, new Date().toISOString()).run()).meta.last_row_id;
      }
      const n = await env.DB.prepare("SELECT title, body, url FROM notifications WHERE id = ?").bind(id).first();
      if (!n) return json({ error: "not_found" }, 404);
      const { results: subs } = await env.DB.prepare("SELECT rowid AS rid, endpoint, p256dh, auth FROM push_subscriptions WHERE rowid > ? ORDER BY rowid LIMIT ?").bind(after, BATCH).all();
      const payload = JSON.stringify({ title: n.title, body: n.body, url: n.url || "/", tag: "notif-" + id });
      const subject = env.VAPID_SUBJECT || url.origin;
      let sent = 0, fail = 0; const dead = [];
      await Promise.all((subs || []).map(async s => {
        try { const st = await sendOne(env, s, payload, subject); if (st >= 200 && st < 300) sent++; else { fail++; if (st === 404 || st === 410) dead.push(s.endpoint); } }
        catch (e) { fail++; }
      }));
      if (dead.length) await env.DB.batch(dead.map(e => env.DB.prepare("DELETE FROM push_subscriptions WHERE endpoint = ?").bind(e)));
      await env.DB.prepare("UPDATE notifications SET sent_count = COALESCE(sent_count,0) + ?, fail_count = COALESCE(fail_count,0) + ? WHERE id = ?").bind(sent, fail, id).run();
      const last = subs && subs.length ? subs[subs.length - 1].rid : after;
      return json({ ok: true, id, sent, fail, after: last, done: !subs || subs.length < BATCH });
    }
    return null;
  } catch (e) {
    return json({ error: "server_error", message: String(e && e.message || e) }, 500);
  }
}
